"""Paths and global settings. Override locations with environment variables."""
import os
from pathlib import Path

DATA_DIR = Path(os.environ.get(
    "BER_DATA_DIR",
    "D:/mlchallenge/6ab10eb3b23ba_student_resource/student_resource/dataset"))
WORK_DIR = Path(os.environ.get("BER_WORK_DIR", "D:/mlchallenge/work"))
OUT_DIR = Path(os.environ.get("BER_OUT_DIR", "D:/mlchallenge/submission/output"))

N_JOBS = int(os.environ.get("BER_N_JOBS", os.cpu_count() or 4))          # threads (matmul, rapidfuzz)
N_PROCS = int(os.environ.get("BER_N_PROCS", min(6, os.cpu_count() or 4)))  # processes (RAM-heavy)
SEED = 42

for _d in (WORK_DIR, OUT_DIR):
    _d.mkdir(parents=True, exist_ok=True)

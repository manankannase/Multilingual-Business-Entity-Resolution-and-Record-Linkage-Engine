"""Stage 2: stage-1 probability + context features -> second LightGBM -> decision.

  python stage2.py fit       # OOF stage-1 on train (2 state folds), context features, stage-2 model, val sweep
  python stage2.py predict   # context features on test (stage-1 scores from pipeline.predict), final TSV
"""
import json
import sys
import time

import lightgbm as lgb
import numpy as np
import polars as pl

from config import N_JOBS, OUT_DIR, SEED, WORK_DIR
from context import CTX_COLS, CTX_STR, context_features, expected_f05_select
from data import load_ground_truth
from decide import evaluate, one_to_one, sweep, write_lists
from pipeline import FEAT, s1_subset
from prep import scan_norm

P_MIN = 0.01          # context is computed over pairs with stage-1 p >= P_MIN (same rule on every split)
S1_PARAMS = dict(objective="binary", learning_rate=0.05, num_leaves=127, min_data_in_leaf=100,
                 feature_fraction=0.8, bagging_fraction=0.8, bagging_freq=1, lambda_l2=1.0,
                 max_bin=127, num_threads=N_JOBS, verbose=-1, seed=SEED)
S2_PARAMS = dict(S1_PARAMS, num_leaves=63, learning_rate=0.03)


def _X(df, cols):
    return df.select(cols).cast(pl.Float32).to_numpy()


def cand_attrs(split: str, ids: pl.Series) -> pl.DataFrame:
    """Normalised fields of the given S2/S3 records (lazy filter: never loads the whole pool)."""
    frames = [pl.scan_parquet(WORK_DIR / "norm" / f"{split}_source{s}.parquet")
                .select(["entity_id"] + CTX_STR).filter(pl.col("entity_id").is_in(ids.implode())).collect()
              for s in (2, 3)]
    return pl.concat(frames)


def oof_train(tr: pl.DataFrame, cols, iters: int) -> np.ndarray:
    """Out-of-fold stage-1 scores for the training pairs; folds are whole states (keeps competition intact)."""
    st = scan_norm("train", 1, ["entity_id", "state"]).rename({"entity_id": "s1"})
    tr_st = tr.select("s1").join(st, on="s1", how="left", maintain_order="left")["state"]
    states = sorted(tr_st.unique().to_list())
    rng = np.random.default_rng(SEED)
    fold_of = {s: int(rng.integers(2)) for s in states}
    fold = tr_st.replace_strict(fold_of, default=0).to_numpy()
    oof = np.zeros(len(tr), np.float32)
    for k in (0, 1):
        trn, hold = fold != k, fold == k
        d = lgb.Dataset(_X(tr.filter(pl.Series(trn)), cols), tr["y"].to_numpy()[trn])
        m = lgb.train(S1_PARAMS, d, iters)
        oof[hold] = m.predict(_X(tr.filter(pl.Series(hold)), cols))
        print(f"  OOF fold {k}: {hold.sum():,} pairs scored", flush=True)
    return oof


def build_ctx(df: pl.DataFrame, split: str) -> pl.DataFrame:
    keep = df.filter(pl.col("p") >= P_MIN)
    return context_features(keep, cand_attrs(split, keep["cand"].unique()))


def fit():
    meta = json.load(open(WORK_DIR / "lgb_v1.json"))
    cols, iters = meta["cols"], meta["iters"]
    tr = pl.read_parquet(FEAT / "train.parquet")
    va = pl.read_parquet(FEAT / "val.parquet")
    t0 = time.time()
    tr = tr.with_columns(pl.Series("p", oof_train(tr, cols, iters)))
    m1 = lgb.Booster(model_file=str(WORK_DIR / "lgb_v1.txt"))
    va = va.with_columns(pl.Series("p", m1.predict(_X(va, cols)).astype(np.float32)))
    print(f"stage-1 scores ready ({time.time() - t0:.0f}s)", flush=True)
    tr, va = build_ctx(tr, "train"), build_ctx(va, "train")
    cols2 = cols + ["p"] + CTX_COLS
    dtr = lgb.Dataset(_X(tr, cols2), tr["y"].to_numpy(), feature_name=cols2)
    dva = lgb.Dataset(_X(va, cols2), va["y"].to_numpy(), reference=dtr)
    m2 = lgb.train(S2_PARAMS, dtr, 3000, valid_sets=[dva],
                   callbacks=[lgb.early_stopping(100), lgb.log_evaluation(200)])
    m2.save_model(str(WORK_DIR / "lgb_s2.txt"))
    va = va.with_columns(pl.Series("p2", m2.predict(_X(va, cols2)).astype(np.float32)))
    va.select("s1", "cand", "p", "p2", "y").write_parquet(WORK_DIR / "val_scored_s2.parquet")

    val_ids = s1_subset("train")["val"]
    truth = load_ground_truth().rename({"source1_entity_id": "s1", "match": "cand"}) \
                               .filter(pl.col("s1").is_in(val_ids.implode()))
    grid = np.round(np.arange(0.3, 0.97, 0.02), 2)
    (t1, f1), _ = sweep(va.select("s1", "cand", "p"), truth, val_ids, grid, score="p")
    (t2, f2), res = sweep(va.select("s1", "cand", "p2"), truth, val_ids, grid, score="p2")
    ef = evaluate(expected_f05_select(one_to_one(va.select("s1", "cand", "p2"), "p2"), score="p2"),
                  truth, val_ids)
    print(f"stage-1 only : F0.5 {f1:.4f} @ {t1}")
    print(f"stage-2      : F0.5 {f2:.4f} @ {t2}")
    print(f"stage-2 + expected-F0.5 selection: F0.5 {ef:.4f}")
    print("stage-2 sweep:", [(t, round(s, 4)) for t, s in res])
    imp = sorted(zip(cols2, m2.feature_importance("gain")), key=lambda x: -x[1])
    print("top stage-2 features:", [(c, int(g)) for c, g in imp[:15]])
    rule = "expected" if ef > f2 else "threshold"
    json.dump({"threshold": float(t2), "val_f05": max(f2, ef), "rule": rule, "cols": cols2,
               "stage1_val_f05": f1}, open(WORK_DIR / "lgb_s2.json", "w"))


def predict():
    meta = json.load(open(WORK_DIR / "lgb_s2.json"))
    m2 = lgb.Booster(model_file=str(WORK_DIR / "lgb_s2.txt"))
    scored = pl.read_parquet(WORK_DIR / "test_scored.parquet")          # s1, cand, p (stage 1, p >= 0.01)
    ctx = build_ctx(scored, "test").select(["s1", "cand"] + CTX_COLS)
    print(f"test context: {len(ctx):,} pairs", flush=True)
    s1_cols = [c for c in meta["cols"] if c not in CTX_COLS]           # stage-1 features + p
    out = []
    for f in sorted((FEAT / "test_shards").glob("*.parquet")):
        sh = pl.read_parquet(f, columns=["s1", "cand"] + [c for c in s1_cols if c != "p"])
        sh = sh.join(scored, on=["s1", "cand"], how="inner").join(ctx, on=["s1", "cand"], how="inner")
        if len(sh):
            out.append(sh.select("s1", "cand", pl.Series("p2", m2.predict(_X(sh, meta["cols"])).astype(np.float32))))
    te = pl.concat(out)
    te.write_parquet(WORK_DIR / "test_scored_s2.parquet")
    o = one_to_one(te, "p2")
    final = expected_f05_select(o, score="p2") if meta["rule"] == "expected" else \
        o.filter(pl.col("p2") >= meta["threshold"]).select("s1", "cand")
    s1_ids = scan_norm("test", 1, ["entity_id"])["entity_id"].to_list()
    res = write_lists(s1_ids, final, OUT_DIR / "matching_results.tsv", "matched_entity_ids")
    n = res["matched_entity_ids"].str.len_chars()
    print(f"wrote {len(res):,} rows; empty {(n == 0).mean():.3f}; mean matches {final.height / len(res):.2f}")


if __name__ == "__main__":
    {"fit": fit, "predict": predict}[sys.argv[1]]()

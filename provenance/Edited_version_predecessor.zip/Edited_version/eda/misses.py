import sys; sys.path.insert(0,"D:/mlchallenge/submission/code/business_entity_resolution/src")
import polars as pl
from prep import normalise
from data import load_ground_truth
u=pl.read_parquet("D:/mlchallenge/work/block_exp.parquet")
s1=normalise("train",1)
ids=s1.select("entity_id").sample(20000,seed=7)  # same sample? verify
s1s=normalise("train",1).sample(20000,seed=7)
gt=load_ground_truth().drop_nulls().filter(pl.col("source1_entity_id").is_in(s1s["entity_id"].implode())).rename({"source1_entity_id":"s1","match":"cand"})
found=u.filter(pl.col("y")==1).select("s1","cand")
miss=gt.join(found,on=["s1","cand"],how="anti")
print("true",len(gt),"missed",len(miss))
o=pl.concat([normalise("train",2),normalise("train",3)])
cols=["entity_id","business_name","business_address","name_core","addr_clean","country","is_domain"]
m=miss.join(s1s.select(cols),left_on="s1",right_on="entity_id").join(o.select(cols),left_on="cand",right_on="entity_id",suffix="_b")
m=m.with_columns(pl.col("business_name_b").str.contains(r"[^\x00-\u024f]").alias("nonlatin"),(pl.col("addr_clean_b")=="").alias("empty_addr"))
print(m.group_by("country").len())
print("nonlatin",m["nonlatin"].mean()," empty addr b",m["empty_addr"].mean()," domain",m["is_domain_b"].mean())
# of missed pairs: was the S1 found other matches?
with pl.Config(fmt_str_lengths=70,tbl_rows=40,tbl_width_chars=250):
    print(m.select("business_name","business_address","business_name_b","business_address_b").sample(30,seed=2))

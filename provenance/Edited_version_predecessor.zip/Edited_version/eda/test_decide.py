import sys; sys.path.insert(0, "D:/mlchallenge/submission/code/business_entity_resolution/src")
import polars as pl, numpy as np
from data import load_ground_truth
from decide import one_to_one, evaluate
from context import expected_f05_select
va = pl.read_parquet("D:/mlchallenge/work/v1/val_scored.parquet")
ids = va["s1"].unique()
truth = load_ground_truth().rename({"source1_entity_id": "s1", "match": "cand"}).filter(pl.col("s1").is_in(ids.implode()))
# val S1 with no candidates at all are in truth but not in va -> evaluate over truth ids
all_ids = truth["s1"].unique()
o = one_to_one(va)
print("threshold 0.74 :", round(evaluate(o.filter(pl.col("p") >= 0.74).select("s1", "cand"), truth, all_ids), 5))
for mp in (0.05, 0.2):
    sel = expected_f05_select(o, min_p=mp)
    print(f"expected-F0.5 (min_p {mp}):", round(evaluate(sel, truth, all_ids), 5))

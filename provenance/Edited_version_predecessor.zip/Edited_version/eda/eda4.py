import pandas as pd, re, numpy as np
D="D:/mlchallenge/6ab10eb3b23ba_student_resource/student_resource/dataset/"
rd=lambda p,**k: pd.read_csv(D+p,sep="\t",dtype=str,keep_default_na=False,quoting=3,**k)
gt=rd("train/train_ground_truth.tsv").sample(60000,random_state=0)
e=gt.assign(m=gt.matched_entity_ids.str.split(",")).explode("m"); e=e[e.m!=""]
need=set(e.m)
o=pd.concat([rd("train/train_source2.tsv"),rd("train/train_source3.tsv")]); o=o[o.entity_id.isin(need)].set_index("entity_id").add_suffix("_o")
s1=rd("train/train_source1.tsv").set_index("entity_id")
e=e.join(o,on="m").join(s1,on="source1_entity_id")
STOP={"inc","llc","ltd","limited","pvt","private","corp","corporation","co","company","the","and","of","llp","pllc","group","services","sas","sarl"}
tok=lambda s:set(t for t in re.findall(r"[a-z0-9]+",s.lower()) if t not in STOP and len(t)>1)
nums=lambda s:set(re.findall(r"\d+",s))
latin=e.business_name_o.map(lambda s: all(ord(c)<0x250 for c in s))
a=e.business_name.map(tok); b=e.business_name_o.map(tok)
share=[len(x&y)>0 for x,y in zip(a,b)]
e["share_name_tok"]=share
e["share_num"]=[len(nums(x)&nums(y))>0 for x,y in zip(e.business_address,e.business_address_o)]
e["share_addr_tok"]=[len(tok(x)&tok(y))>0 for x,y in zip(e.business_address,e.business_address_o)]
e["latin"]=latin
print(e.groupby("latin")[["share_name_tok","share_num","share_addr_tok"]].mean())
print("any of (name tok | addr num):",(e.share_name_tok|e.share_num).mean())
print("frac of pairs where other name non-latin:",1-latin.mean())

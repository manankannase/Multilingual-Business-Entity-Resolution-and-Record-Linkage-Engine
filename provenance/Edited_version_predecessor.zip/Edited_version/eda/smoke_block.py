import sys, time; sys.path.insert(0, "D:/mlchallenge/submission/code/business_entity_resolution/src")
import polars as pl
from prep import scan_norm
from blocking import run_country, BLOCK_COLS
if __name__ == "__main__":
    s1 = scan_norm("test", 1, BLOCK_COLS, "France").sample(20000, seed=1)
    pool = pl.concat([scan_norm("test", 2, BLOCK_COLS, "France"), scan_norm("test", 3, BLOCK_COLS, "France")]).sample(150000, seed=1)
    t = time.time(); u = run_country(s1, pool); print(u.shape, f"{time.time()-t:.0f}s"); print(u.columns); print(u.head(3))

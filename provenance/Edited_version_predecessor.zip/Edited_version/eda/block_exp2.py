"""Recall of partitioned blocking: 20k train S1 sample (queries) vs full pool; all S1 act as competitors.
Memory-lean: one country at a time, per-country results saved to disk (resumable)."""
import sys, time, gc
sys.path.insert(0, "D:/mlchallenge/submission/code/business_entity_resolution/src")
import numpy as np, polars as pl
from multiprocessing import Pool
from prep import scan_norm
from data import load_ground_truth
from blocking import run_country, BLOCK_COLS
from config import N_PROCS, WORK_DIR

OUT = WORK_DIR / "block_exp2"


def main():
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
    OUT.mkdir(exist_ok=True)
    samp = set(scan_norm("train", 1, ["entity_id"]).sample(N, seed=7)["entity_id"].to_list())
    W = Pool(N_PROCS)
    for country in ["US", "India"]:
        f = OUT / f"{country}.parquet"
        if f.exists():
            print(country, "cached", flush=True)
            continue
        s1 = scan_norm("train", 1, BLOCK_COLS, country)
        pool = pl.concat([scan_norm("train", 2, BLOCK_COLS, country), scan_norm("train", 3, BLOCK_COLS, country)])
        keep = np.array([e in samp for e in s1["entity_id"].to_list()])
        t = time.time()
        print(country, keep.sum(), "queries;", len(s1), "S1;", len(pool), "pool", flush=True)
        u = run_country(s1, pool, W, keep)
        print(f"  {country} total {time.time()-t:.0f}s, {len(u):,} pairs", flush=True)
        u = u.with_columns(pl.Series("s1", s1["entity_id"].to_numpy()[u["q"].to_numpy()]),
                           pl.Series("cand", pool["entity_id"].to_numpy()[u["c"].to_numpy()])).drop("q", "c")
        u.write_parquet(f)
        del s1, pool, u
        gc.collect()
    W.close()
    u = pl.concat([pl.read_parquet(OUT / f"{c}.parquet") for c in ["US", "India"]], how="diagonal")
    gt = load_ground_truth().drop_nulls().rename({"source1_entity_id": "s1", "match": "cand"})
    true = gt.filter(pl.col("s1").is_in(list(samp)))
    u = u.join(true.with_columns(pl.lit(1).alias("y")), on=["s1", "cand"], how="left").with_columns(pl.col("y").fill_null(0))
    T = len(true)
    print(f"\ntrue {T:,}; pairs {len(u):,} ({len(u)/N:.1f}/S1); UNION recall {u['y'].sum()/T:.4f}")
    for c in [c for c in u.columns if c.startswith("sim_")]:
        sub = u.filter(pl.col(c).is_not_null())
        print(f"  {c:18s} recall {sub['y'].sum()/T:.4f} pairs/S1 {len(sub)/N:.1f}")
    u.write_parquet(WORK_DIR / "block_exp2.parquet")


if __name__ == "__main__":
    main()

import pandas as pd, re, collections, numpy as np
D="D:/mlchallenge/6ab10eb3b23ba_student_resource/student_resource/dataset/"
rd=lambda p: pd.read_csv(D+p,sep="\t",dtype=str,keep_default_na=False,quoting=3)
SUF=r"\b(inc|llc|l\.l\.c|pllc|corp|corporation|co|company|ltd|limited|pvt|private|llp|lp)\b\.?"
key=lambda s:" ".join(sorted(re.sub(SUF,"",re.sub(r"[^\w\s]"," ",s.lower())).split()))
s1=rd("train/train_source1.tsv"); s1["k"]=s1.business_name.map(key)
vc=s1.k.value_counts(); print("F2: S1 rows whose name key is shared with another S1:",(s1.k.map(vc)>1).mean())
# F7: indic token alignment
gt=rd("train/train_ground_truth.tsv").sample(200000,random_state=1)
e=gt.assign(m=gt.matched_entity_ids.str.split(",")).explode("m"); e=e[e.m!=""]
o=pd.concat([rd("train/train_source2.tsv"),rd("train/train_source3.tsv")]).set_index("entity_id")
e=e.join(o.business_name.rename("n2"),on="m").join(s1.set_index("entity_id").business_name.rename("n1"),on="source1_entity_id")
ind=e[e.n2.map(lambda s:any(ord(c)>0x900 and ord(c)<0xD80 for c in s))]
same=(ind.n1.str.split().str.len()==ind.n2.str.split().str.len()).mean()
print("F7: indic pairs",len(ind)," same token count:",same)
# build dict token-> most common latin token
d=collections.defaultdict(collections.Counter)
tr=ind.sample(frac=0.7,random_state=0); te=ind.drop(tr.index)
for a,b in zip(tr.n1,tr.n2):
    a,b=a.lower().split(),b.split()
    if len(a)==len(b):
        for x,y in zip(a,b): d[y][x]+=1
tot=hit=cor=0
for a,b in zip(te.n1,te.n2):
    a,b=a.lower().split(),b.split()
    if len(a)==len(b):
        for x,y in zip(a,b):
            tot+=1
            if y in d: hit+=1; cor+= d[y].most_common(1)[0][0]==x
print("dict size",len(d)," coverage",hit/tot," accuracy",cor/max(hit,1))

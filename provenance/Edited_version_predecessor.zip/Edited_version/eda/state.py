import sys; sys.path.insert(0,"D:/mlchallenge/submission/code/business_entity_resolution/src")
import polars as pl
from prep import normalise
from data import load_ground_truth
for sp in ["train","test"]:
    for s in (1,2,3):
        d=normalise(sp,s).select("country","state","addr_clean")
        print(sp,s,d.group_by("country").agg((pl.col("state")!="").mean().alias("has_state"),(pl.col("addr_clean")=="").mean().alias("empty_addr"),pl.col("state").n_unique().alias("n_states")).sort("country").rows())
gt=load_ground_truth().drop_nulls().sample(300000,seed=0)
s1=normalise("train",1).select("entity_id","state","country"); o=pl.concat([normalise("train",2),normalise("train",3)]).select("entity_id","state")
p=gt.join(s1,left_on="source1_entity_id",right_on="entity_id").join(o,left_on="match",right_on="entity_id",suffix="_b")
print(p.group_by("country").agg((pl.col("state")==pl.col("state_b")).mean().alias("same"),((pl.col("state")!=pl.col("state_b"))&(pl.col("state_b")!="")&(pl.col("state")!="")).mean().alias("conflict"),(pl.col("state_b")=="").mean().alias("b_missing")).rows())
c=p.filter((pl.col("state")!=pl.col("state_b"))&(pl.col("state_b")!="")&(pl.col("state")!=""))
print(c.group_by("state","state_b").len().sort("len",descending=True).head(15).rows())
print(normalise("train",1).filter(pl.col("country")=="US").group_by("state").len().sort("len",descending=True).head(60)["state"].to_list())

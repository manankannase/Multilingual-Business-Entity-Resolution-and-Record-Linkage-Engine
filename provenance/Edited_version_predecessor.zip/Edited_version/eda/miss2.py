import sys; sys.path.insert(0,"D:/mlchallenge/submission/code/business_entity_resolution/src")
import polars as pl
from prep import scan_norm
from data import load_ground_truth
cand=pl.read_parquet("D:/mlchallenge/work/cand/val.parquet",columns=["s1","cand"])
ids=cand["s1"].unique()
gt=load_ground_truth().drop_nulls().filter(pl.col("source1_entity_id").is_in(ids.implode())).rename({"source1_entity_id":"s1","match":"cand"})
# val S1 with zero candidates are not in cand -> use subset from gt too
miss=gt.join(cand,on=["s1","cand"],how="anti")
print("missed",len(miss),"of",len(gt))
cols=["entity_id","country","business_name","business_address","name_core","addr_clean","state","city","house"]
lf=lambda sp,s: pl.scan_parquet(f"D:/mlchallenge/work/norm/{sp}_source{s}.parquet").select(cols)
A=lf("train",1).filter(pl.col("entity_id").is_in(miss["s1"].implode())).collect()
B=pl.concat([lf("train",2),lf("train",3)]).filter(pl.col("entity_id").is_in(miss["cand"].implode())).collect()
m=miss.join(A,left_on="s1",right_on="entity_id").join(B,left_on="cand",right_on="entity_id",suffix="_b")
m=m.with_columns((pl.col("addr_clean_b")=="").alias("b_empty"),pl.col("business_name_b").str.contains(r"[^\x00-\x7F]").alias("b_nonascii"),
   (pl.col("state_b")=="").alias("b_nostate"),(pl.col("state")!=pl.col("state_b")).alias("state_diff"))
print(m.group_by("country").len().rows())
print(m.select(pl.col("b_empty","b_nonascii","b_nostate","state_diff").mean()).rows(named=True))
print("state diff but both present:",m.filter(pl.col("state_diff")&~pl.col("b_nostate")).group_by("state","state_b").len().sort("len",descending=True).head(10).rows())
with pl.Config(fmt_str_lengths=60,tbl_rows=30,tbl_width_chars=260):
    print(m.filter(~pl.col("b_empty")).select("business_name","business_address","business_name_b","business_address_b").sample(20,seed=1))
    print(m.filter(pl.col("b_empty")).select("business_name","business_address","business_name_b","name_core","name_core_b").sample(12,seed=1))

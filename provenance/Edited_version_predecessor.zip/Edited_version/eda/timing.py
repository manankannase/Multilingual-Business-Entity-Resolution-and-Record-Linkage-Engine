import sys, time; sys.path.insert(0,"D:/mlchallenge/submission/code/business_entity_resolution/src")
import polars as pl
from multiprocessing import Pool
from prep import normalise
from blocking import BLOCK_COLS, VIEWS, view_text, fit_vectorizer, par_transform, topk
def main():
    W=Pool(16)
    pool=pl.concat([normalise("train",2).select(BLOCK_COLS),normalise("train",3).select(BLOCK_COLS)]).filter(pl.col("country")=="US")
    s1=normalise("train",1).select(BLOCK_COLS).filter(pl.col("country")=="US")
    for v in ["name_addr","name"]:
        t=time.time(); txt=view_text(pool,v); vec=fit_vectorizer(txt,VIEWS[v][1]); t1=time.time()
        B=par_transform(vec,txt,W); t2=time.time()
        A=par_transform(vec,view_text(s1.head(50000),v),W); BT=B.T.tocsr(); t3=time.time()
        r=topk(A,BT,15); t4=time.time()
        print(v,f"fit {t1-t:.0f}s transform pool {t2-t1:.0f}s  A+BT {t3-t2:.0f}s  matmul 50k q {t4-t3:.0f}s  nnz/row B {B.nnz/B.shape[0]:.1f}",flush=True)
        # reverse: pool queries vs S1 index
        S=par_transform(vec,view_text(s1,v),W); ST=S.T.tocsr(); t5=time.time()
        r=topk(B[:200000],ST,5); t6=time.time()
        print(f"   reverse: S1 transform {t5-t4:.0f}s; 200k pool queries vs {S.shape[0]:,} S1: {t6-t5:.0f}s",flush=True)
if __name__=="__main__": main()

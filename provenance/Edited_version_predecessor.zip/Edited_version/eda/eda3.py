import pandas as pd, re, unicodedata, collections
D="D:/mlchallenge/6ab10eb3b23ba_student_resource/student_resource/dataset/"
def script(s):
    for ch in s:
        if ord(ch)>0x24F and ch.isalpha():
            return unicodedata.name(ch,"?").split()[0]
    return "LATIN"
for f in ["train/train_source2.tsv","train/train_source3.tsv","test/test_source2.tsv","test/test_source1.tsv","train/train_source1.tsv"]:
    df=pd.read_csv(D+f,sep="\t",dtype=str,keep_default_na=False,quoting=3,nrows=300000)
    sc=df.business_name.map(script)
    print(f,collections.Counter(sc).most_common(8))
    print("  domain-like names:",df.business_name.str.contains(r"\.(com|in|net|org|fr|co)\b",case=False).mean())
    print("  addr has digit:",df.business_address.str.contains(r"\d").mean())
    fr=df[df.country=="France"]
    if len(fr): print(fr.sample(6,random_state=1).to_string())

import pandas as pd, numpy as np, collections
D="D:/mlchallenge/6ab10eb3b23ba_student_resource/student_resource/dataset/"
rd=lambda p: pd.read_csv(D+p,sep="\t",dtype=str,keep_default_na=False,quoting=3)
gt=rd("train/train_ground_truth.tsv")
e=gt.assign(m=gt.matched_entity_ids.str.split(",")).explode("m"); e=e[e.m!=""]
c=e.m.value_counts(); print("S2/S3 ids linked to >1 S1:",(c>1).sum(),"of",len(c))
s1=rd("train/train_source1.tsv").set_index("entity_id")
s2=rd("train/train_source2.tsv"); s3=rd("train/train_source3.tsv"); o=pd.concat([s2,s3]).set_index("entity_id").add_suffix("_o")
print("unmatched S2+S3:",len(o)-len(c))
e=e.join(o,on="m").join(s1,on="source1_entity_id")
print("cross-country pairs:",(e.country!=e.country_o).mean())
# exact equality rates
print("exact name eq:",(e.business_name.str.lower()==e.business_name_o.str.lower()).mean())
print("exact addr eq:",(e.business_address.str.lower()==e.business_address_o.str.lower()).mean())
rng=np.random.default_rng(0)
for sid in rng.choice(gt.source1_entity_id[gt.matched_entity_ids!=""].values,10,replace=False):
    r=s1.loc[sid]; print("\n###",sid,"|",r.business_name,"|",r.business_address,"|",r.country)
    for m in e[e.source1_entity_id==sid].itertuples(): print("   ",m.m,"|",m.business_name_o,"|",m.business_address_o)
# unmatched sample
um=o.index.difference(c.index); 
print("\n--- unmatched S2/S3 samples"); print(o.loc[rng.choice(um,8,replace=False)].to_string())

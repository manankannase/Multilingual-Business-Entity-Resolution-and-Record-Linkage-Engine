import sys, time; sys.path.insert(0, "D:/mlchallenge/submission/code/business_entity_resolution/src")
import polars as pl
from stage2 import build_ctx
from context import CTX_COLS
if __name__ == "__main__":
    va = pl.read_parquet("D:/mlchallenge/work/v1/val_scored.parquet").head(300000)
    t = time.time(); c = build_ctx(va, "train"); print(c.shape, f"{time.time()-t:.1f}s")
    print(c.select(CTX_COLS).describe().transpose(include_header=True).select("statistic", "mean", "min", "max") if False else c.select(CTX_COLS).mean().transpose(include_header=True))

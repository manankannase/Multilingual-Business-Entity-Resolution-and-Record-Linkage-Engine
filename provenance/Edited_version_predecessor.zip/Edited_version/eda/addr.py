import pandas as pd
D="D:/mlchallenge/6ab10eb3b23ba_student_resource/student_resource/dataset/"
for f in ["train/train_source1.tsv","train/train_source2.tsv","train/train_source3.tsv","test/test_source3.tsv"]:
    df=pd.read_csv(D+f,sep="\t",dtype=str,keep_default_na=False,quoting=3,nrows=400000)
    na=df.business_address.map(lambda s:any(ord(c)>0x24f and c.isalpha() for c in s)).mean()
    print("==",f,"non-latin addr frac",round(na,4))
    for c in ["India","US","France"]:
        x=df[df.country==c]
        if len(x): print(c); print("\n".join("   "+a for a in x.business_address.sample(7,random_state=3)))

import pandas as pd, numpy as np, sys
D="D:/mlchallenge/6ab10eb3b23ba_student_resource/student_resource/dataset/"
rd=lambda p: pd.read_csv(D+p,sep="\t",dtype=str,keep_default_na=False,quoting=3)
gt=rd("train/train_ground_truth.tsv")
lst=gt.matched_entity_ids.str.split(",")
n=lst.map(lambda l: 0 if l==[''] else len(l))
print("GT rows",len(gt),"singleton frac",(n==0).mean())
print("matches/entity dist:\n",n.value_counts().sort_index().head(15))
n2=lst.map(lambda l: sum(x.startswith("S2") for x in l)); n3=lst.map(lambda l: sum(x.startswith("S3") for x in l))
print("S2 per entity:\n",n2.value_counts().sort_index().head(10)); print("S3 per entity:\n",n3.value_counts().sort_index().head(10))
for s in ["train/train_source1.tsv","test/test_source1.tsv","train/train_source2.tsv","test/test_source2.tsv","train/train_source3.tsv","test/test_source3.tsv"]:
    df=rd(s); print(s,len(df)); print(df.country.value_counts().head(8).to_dict()); print(" empty name",(df.business_name=="").mean()," empty addr",(df.business_address=="").mean())
    if "train_source1" in s: s1=df
# how many S2/S3 train records appear in GT at all
allm=set(x for l in lst for x in l if x)
print("distinct matched ids",len(allm))
s1=s1.merge(gt,left_on="entity_id",right_on="source1_entity_id")
s1["n"]=s1.matched_entity_ids.map(lambda x:0 if x=="" else x.count(",")+1)
print(s1.groupby("country").n.agg(["mean",lambda x:(x==0).mean()]))

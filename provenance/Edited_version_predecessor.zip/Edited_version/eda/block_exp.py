"""Blocking recall experiment on a validation sample of train S1 against the FULL train S2+S3 pool."""
import sys
import time
sys.path.insert(0, "D:/mlchallenge/submission/code/business_entity_resolution/src")
import numpy as np
import polars as pl
from prep import normalise
from data import load_ground_truth
from blocking import run_view, BLOCK_COLS
from multiprocessing import Pool
from config import N_JOBS



def main():
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 20000
    K = int(sys.argv[2]) if len(sys.argv) > 2 else 30
    s1 = normalise("train", 1).select(BLOCK_COLS).sample(N, seed=7)
    pool_all = pl.concat([normalise("train", 2).select(BLOCK_COLS), normalise("train", 3).select(BLOCK_COLS)])
    gt = load_ground_truth().drop_nulls()

    res = []
    W = Pool(N_JOBS)
    for country in ["US", "India"]:
        q = s1.filter(pl.col("country") == country)
        pool = pool_all.filter(pl.col("country") == country)
        print(country, len(q), "S1 vs pool", len(pool), flush=True)
        parts = [run_view(q, pool, v, K, W) for v in ("name", "addr", "name_addr")]
        u = parts[0]
        for p in parts[1:]:
            u = u.join(p, on=["q", "c"], how="full", coalesce=True)
        u = u.with_columns(pl.Series("s1", q["entity_id"].to_numpy()[u["q"].to_numpy()]),
                           pl.Series("cand", pool["entity_id"].to_numpy()[u["c"].to_numpy()]))
        res.append(u.drop("q", "c"))
    u = pl.concat(res, how="diagonal")
    true = gt.filter(pl.col("source1_entity_id").is_in(s1["entity_id"].implode())).rename(
        {"source1_entity_id": "s1", "match": "cand"}).with_columns(pl.lit(1).alias("y"))
    u = u.join(true, on=["s1", "cand"], how="left").with_columns(pl.col("y").fill_null(0))
    T = len(true)
    print(f"\ntrue pairs {T:,}; union pairs {len(u):,} ({len(u)/N:.1f}/S1); union recall {u['y'].sum()/T:.4f}")
    for v in ("name", "addr", "name_addr"):
        for k in (5, 10, 20, K):
            sub = u.filter(pl.col(f"rank_{v}") <= k)
            print(f"  {v:10s} @{k:3d}: recall {sub['y'].sum()/T:.4f}  pairs/S1 {len(sub)/N:.1f}")
    for k in (5, 10, 15, 20, K):
        sub = u.filter(pl.any_horizontal(pl.col(f"rank_{v}") <= k for v in ("name", "addr", "name_addr")))
        print(f"  UNION @{k:3d}: recall {sub['y'].sum()/T:.4f}  pairs/S1 {len(sub)/N:.1f}")
    u.write_parquet("D:/mlchallenge/work/block_exp.parquet")


if __name__ == '__main__':
    main()

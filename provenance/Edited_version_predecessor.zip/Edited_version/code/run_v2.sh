#!/bin/bash
# v2: features (resumable, process recycled every 6 chunks) -> stage-1 fit/predict -> stage 2 -> validate
set -u
cd /d/mlchallenge/submission/code/business_entity_resolution/src
feat() { while true; do python -u pipeline.py features "$1"; rc=$?; [ $rc -eq 0 ] && return 0; [ $rc -eq 3 ] || return $rc; done; }
feat train || exit 1
feat test || exit 1
python -u pipeline.py fit || exit 1
python -u pipeline.py predict || exit 1
cp /d/mlchallenge/submission/output/matching_results.tsv /d/mlchallenge/work/matching_results_v2_stage1.tsv
python -u stage2.py fit || exit 1
python -u stage2.py predict || exit 1
cd /d/mlchallenge/6ab10eb3b23ba_student_resource/student_resource
python utils/validate_submission.py --matching /d/mlchallenge/submission/output/matching_results.tsv --candidate /d/mlchallenge/submission/output/candidate_pairs.tsv --test-dir dataset/test

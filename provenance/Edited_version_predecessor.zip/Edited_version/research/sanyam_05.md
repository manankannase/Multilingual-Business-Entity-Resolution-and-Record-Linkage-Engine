# Revised Strategy — What Actually Moves F0.5 on This Dataset
## Critique of plans 01–04 + verified data findings + 72-hour execution plan

Everything in section 1 was measured directly on the training data (scripts were run against
the full `dataset/train/*` files), not estimated.

---

## 1. Verified findings that change the plan

| # | Finding (measured) | Why it matters |
|---|---|---|
| F1 | **Every S2/S3 record matches at most ONE S1** (7,638,365 GT pairs, 7,638,365 unique S2/S3 IDs) | Hard assignment constraint. Plan 02 §6.1 uses `max_s1_per_candidate=2` — should be 1, and used as a model feature, not only a filter. |
| F2 | **Names are heavily reused across S1**: 51% of S1 rows share a suffix-stripped, sorted-token name key with another S1 row (e.g. "007 Costamare LLC" ×5 in 5 cities) | Name similarity alone cannot pick the right S1. Among same-name-key US pairs: 0.6M true vs **18.9M false**. Address is the primary discriminator, not a secondary one. |
| F3 | **Distractors are adversarial twins, not random**: ~30% of distractors share a name key with some S1; ~70% of *singletons* have a same-name record in S2/S3 | Singletons are "hard": they have a lookalike that must be rejected. Plan 02 §5.2 random-distractor negatives are useless (they never reach the candidate set). |
| F4 | Address separates most twins: token-Jaccard median 0.50 (true) vs 0.00 (twins); numeric-token overlap median 1.0 vs 0.0 | Invest in address parsing: house number, street name, city, state. |
| F5 | Residual hard case: ~1% of twin distractors sit on the **same street with a nearby number** (7751 vs 7755, 758 vs 759). True matches also carry number noise: leading zeros (`00412`), truncation (`1515→151`), ±1 (`5952→5951`), even full replacement (`161→519`, where **S2 and S3 agree with each other but not S1**) | Pairwise features hit a ceiling here. Needs (a) rich number features, (b) **cluster context** (do the other S2/S3 candidates agree?), (c) one-to-one competition. |
| F6 | ~18% of true pairs share *no* numbers at all (candidate dropped the house number) | Missing number ≠ mismatched number. Separate features for "absent" vs "different". |
| F7 | **Indic-script names are word-by-word phonetic renderings of the same English vocabulary** (100% token-count alignment in 551K pairs). A dictionary learned from train pairs (1,498 entries) covers 100% of held-out tokens at 96.7% accuracy and **96.4% of test Indic tokens** | Replace library transliteration as the primary method. `aksharamukha` is AGPL-licensed — avoid; use `indic-transliteration` (MIT) only as fallback for the ~3.6% uncovered test tokens. |
| F8 | Test has more S2+S3 per S1 than train (5.75 vs 4.68, uniformly across countries) and lower S2/S3→S1 name-key hit rates (US 0.548→0.502, India 0.484→0.428) | Test likely has **more distractors / orphaned clusters** (~35–40% vs 26%). Thresholds tuned on a plain train split will be too loose. Validation must simulate this (see §3). |
| F9 | No leakage: row order and ID numbers are uncorrelated between S1 and matches (r ≈ 0.001) | Don't spend time looking for shortcuts. |

---

## 2. Verdict on plans 01–04

**Keep:** the noise catalog (03), normalization steps (accents, l33t, prefix garbage, `null`, DBA,
domain decoding, suffix maps incl. French), most pairwise features (04), group-wise CV, F0.5-tuned
thresholds.

**Change / drop:**

| Plan item | Problem | Replace with |
|---|---|---|
| 10 unioned blocking strategies, 50–150 cands/S1 | Name-only blockers get flooded by same-name entities (F2); too many pairs for a cross-encoder | 3 blockers on **name + address**, measured recall@K, ~30–60 cands then prune to ~15–20 |
| `all-MiniLM-L6-v2`, `ms-marco-MiniLM` | English-only: cannot read Devanagari/Tamil/…; weak on French | Multilingual models (MIT): `intfloat/multilingual-e5-base/large`, `BAAI/bge-m3`, `microsoft/mdeberta-v3-base`, `xlm-roberta-large` (verify licence on each model card) |
| Cross-encoder only on 0.4–0.6 borderline | Leaves the strongest signal unused on most pairs | Fine-tuned cross-encoder on **all** pruned candidates, used as a feature |
| LGB + XGB + CatBoost + LR stacking | Same features → highly correlated models, small gain | **Two-stage**: pairwise model → context model with cross-candidate features (§4.5) |
| Graph rules with hand-set ×1.05 boosts | Untuned heuristics | Learn them: turn them into features for the context model |
| Global / per-country threshold | Ignores per-entity structure of macro F0.5 | **Per-S1 expected-F0.5 subset selection** on calibrated probabilities (§4.6) |
| Random distractor negatives, 8:1 ratio | Not in candidate set → no signal | Train on the actual blocking output (natural hard negatives) |
| Score projection table 0.60 → 0.99 | Numbers are guesses, not measurements | Track real validation F0.5 per change in a log |
| 10–13 h timeline | Unrealistic at 12M records | 72 h plan in §5 |

---

## 3. Validation harness (build first, hours 0–4)

1. `GroupKFold` on S1 entity (5 folds). S2/S3 pool is shared; a fold's S1 entities search the **full** S2/S3 pool.
2. **Test-like val set**: in the held-out fold, drop a random ~20% of S1 entities but keep their S2/S3
   records in the pool → orphaned clusters, raising the distractor ratio toward the test's (F8).
   Report F0.5 on both the plain and test-like val; tune decisions on the test-like one.
3. Exact scorer: per-S1 F0.5 macro average, singletons = 1.0 iff empty prediction.
4. Always report: blocking recall, F0.5 overall, by country, singletons vs matched, and an FP/FN sample dump.
5. For France (no labels): report prediction rate/match-count distribution vs US/India as a sanity check.

---

## 4. Pipeline

### 4.1 Normalization (keep plan 02 §3, plus)
- **Learned Indic→Latin token dictionary** from GT pairs (F7); fallback `indic-transliteration` (MIT) + lowercase/vowel-drop phonetic key.
- **Address parser** producing: `house_no` (strip `#`, leading zeros, trailing letters/`-`, keep raw too), `unit`, `street_name` tokens (normalized street types, ordinals `131ND→131st`), `city`, `state` (both `OH↔Ohio`, `DL↔Delhi`, `दिल्ली→delhi`), `pin/zip`. Components are comma-separated but reordered — classify each part by lookup (state list, city vocabulary built from S1) rather than by position.
- Domain names: segment the concatenated base using the vocabulary of S1 name tokens (DP word-break), then compare as tokens; keep concat-vs-concat Levenshtein too.
- Country-agnostic design: do **not** feed `country` as a feature; France must reuse the same features. Add French street types (`r.`, `av`, `bd`, `imp`, `all`, `ch`) and suffixes to the same maps.

### 4.2 Blocking (target: ≥99.5% recall of true pairs, measured on val)
Per country partition:
1. **Dense**: fine-tune `multilingual-e5-base` (or `bge-m3`) as a bi-encoder on `name | address` strings with in-batch + mined hard negatives (same-name-key twins). FAISS-GPU top-50. Handles cross-script, typos, domains, French in one model.
2. **Sparse**: char 3–4-gram TF-IDF on `normalized_name + street_name + city`; sparse top-K (`sparse_dot_topn` or chunked GPU matmul) top-50.
3. **Exact keys**: (street_name, city) and (name_key, city) blocks, capped by block size.
4. **Reverse direction**: for every S2/S3 record, its top-5 S1 → add. Also gives the competition set for F1.

Measure recall of each alone and the union at K = 10/20/50. Then a cheap LightGBM (≈15 fast features) prunes to top ~15–20 per S1 with ≥99.3% recall. **This pruned set is `candidate_pairs.tsv`** (the set the final model scores).

### 4.3 Pairwise features (LightGBM, GPU)
Plan 04 features, plus the ones that target F2/F5/F6:
- House number: raw equal, equal after strip-zeros, one is prefix/suffix of other, |diff|, digit edit distance, both-present / one-absent / both-absent flags.
- Street-name token Jaccard and JW; city equal; state equal; zip/pin equal; unit equal.
- Name: token-set/sort ratios, containment both directions, IDF-weighted overlap (IDF from S1+S2+S3 names), suffix class match, domain-segmented similarity, translit similarity.
- **Name frequency**: how many S1 rows share this name key (high = name is uninformative, rely on address).
- Model scores: bi-encoder cosine, TF-IDF cosine, and their **rank** within the S1's candidate list.
- Candidate source (S2/S3), script, is_domain, has_dba, address empty.

### 4.4 Cross-encoder (biggest single model gain; GPU)
- Backbone: `mdeberta-v3-base` (fast) — then `xlm-roberta-large` if time permits. Both MIT, well under 8B.
- Input: `name1 [SEP] addr1` ⟷ `name2 [SEP] addr2`, max_len ~96–128. Train on pruned candidates from train folds (≈ 1.8M S1 × 15 ≈ 27M pairs; 1–2 epochs on a sample of 8–15M is usually enough). bf16, large batch.
- Inference: 1.73M test S1 × ~15–20 ≈ 26–35M pairs. Budget ~2–4 h on one A100/H100 for a base model — measure throughput early and set K accordingly.
- Out-of-fold predictions for the train set are needed for §4.5 → train on folds 1–4, predict fold 5 (at minimum 2-fold).

### 4.5 Context model (second-stage LightGBM) — fixes F1/F5
Inputs: stage-1 OOF prob + cross-encoder score + per-candidate aggregates:
- Within S1: rank, gap to best, # candidates with p > 0.5, sum of p (expected cluster size).
- **Competition** (F1): this candidate's best score for any *other* S1, is-argmax flag, margin.
- **Cluster agreement** (F5): max/mean similarity (address + name, cheap string sims) between this candidate and the S1's top-3 other candidates, especially across S2↔S3. This is what rescues `161 vs 519` when S2 and S3 agree.
- **Twin flag**: another candidate for this S1 with the same name key but different house number; score difference to it.
- # S1 rows sharing the name key within the same city.

Train with GroupKFold on OOF inputs (no leakage). Calibrate with isotonic regression on OOF.

### 4.6 Decision rule
1. **One-to-one**: each S2/S3 is assigned only to its argmax S1 (optionally require margin); others dropped.
2. **Per-S1 expected-F0.5 maximization**: sort remaining candidates by calibrated p; for k = 0…n compute
   E[F0.5(top-k)] (Monte-Carlo over Bernoulli(p) with ~200 samples, or the ratio-of-expectations
   approximation); pick the best k. k = 0 scores P(no true match) → principled singleton handling.
3. Compare against a tuned global threshold on test-like val; keep whichever wins (expect expected-F to win).

### 4.7 Ensembling (only after the above works)
2 cross-encoder backbones or seeds averaged; 3 LightGBM seeds in the context model. Skip XGB/CatBoost stacking unless val shows a gain.

---

## 5. 72-hour schedule (GPU jobs run in background while CPU work continues)

| Hours | CPU track | GPU track | Exit criterion |
|---|---|---|---|
| 0–6 | Loader (parquet cache), normalization, address parser, translit dict, scorer, test-like val split | — | Scorer reproduces a hand-checked example |
| 6–14 | TF-IDF + exact-key blocking, recall report; ~40 pairwise features; LightGBM; one-to-one + global threshold | Fine-tune bi-encoder | **Submission #1** (baseline on LB) |
| 14–24 | Add dense blocking + reverse blocking, prune model, recall ≥99.3% at K≈15–20; retrain pairwise | Bi-encoder encode + FAISS for train/test | Submission #2 |
| 24–40 | Context features + expected-F0.5 decision; error analysis buckets (country, noise type, twin/singleton) | Cross-encoder train (folds) → OOF + test inference | Submission #3 |
| 40–56 | Add cross-encoder to context model; iterate on top FP/FN buckets; France sanity checks | 2nd backbone / seed | Submission #4–5 |
| 56–64 | Freeze features. Clean `src/`, single entry point, pinned `requirements.txt`, end-to-end rerun from raw TSVs | Final inference | Reproduced outputs match |
| 64–72 | `validate_submission.py`, documentation, zip. **No new ideas after hour 62.** | — | Zip done with buffer |

Throughout: log every experiment (change → val F0.5 plain/test-like → LB) in one table; it becomes the documentation's results section.

---

## 6. Priority if time runs short (highest expected impact first)

1. Address parsing + house-number features (F2–F6) and name-frequency feature
2. Blocking on name+address with measured recall
3. One-to-one assignment + per-S1 expected-F0.5 decision (F1, singletons)
4. Context model with cluster-agreement / competition features
5. Fine-tuned multilingual cross-encoder
6. Learned transliteration dictionary (cheap, do it early anyway)
7. Ensembling

---

## 7. Open questions to settle early
- **Submission limit** on the portal? Determines how much LB probing is possible (e.g. France-only variants).
- **Fair-play rules** on using unlabeled test data (pseudo-labeling France, fitting TF-IDF/IDF on test). Fitting unsupervised statistics on test is usually fine; confirm before pseudo-labeling.
- **GPU spec** (A100/H100 count, VRAM) → sets cross-encoder size and K.

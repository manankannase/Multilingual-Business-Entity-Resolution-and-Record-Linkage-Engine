> **Note:** Background reference only. Where this conflicts with `02_implementation_plan.md` (v2, final), 02 wins.

# Feature Engineering Specification
## 40+ Features for Maximum Discrimination

---

## Feature Categories Overview

| Category | # Features | Purpose |
|---|---|---|
| Name Similarity | 15 | Core matching signal |
| Address Similarity | 12 | Location-based matching |
| Cross/Meta Features | 9 | Interaction and context signals |
| Embedding Features | 4 | Semantic similarity |
| **Total** | **40** | |

---

## Category 1: Name Similarity Features (15)

### F01: `name_jaccard_word`
- **Computation:** Jaccard(word_set(s1_name), word_set(cand_name))
- **Handles:** Token overlap after normalization
- **Range:** [0, 1]

### F02: `name_jaccard_char3gram`
- **Computation:** Jaccard(char_3grams(s1_name), char_3grams(cand_name))
- **Handles:** Typos, abbreviations — character-level overlap
- **Range:** [0, 1]

### F03: `name_levenshtein_norm`
- **Computation:** 1 - (levenshtein(s1_name, cand_name) / max(len(s1), len(cand)))
- **Handles:** Edit-distance based similarity
- **Range:** [0, 1]
- **Library:** `rapidfuzz.distance.Levenshtein`

### F04: `name_jaro_winkler`
- **Computation:** jaro_winkler_similarity(s1_name, cand_name)
- **Handles:** Prefix-weighted similarity, good for names
- **Range:** [0, 1]
- **Library:** `rapidfuzz.distance.JaroWinkler`

### F05: `name_tfidf_cosine`
- **Computation:** Cosine similarity from TF-IDF blocking stage
- **Handles:** IDF-weighted token importance
- **Range:** [0, 1]
- **Note:** Already computed during blocking — reuse!

### F06: `name_exact_match`
- **Computation:** 1 if normalize(s1_name) == normalize(cand_name), else 0
- **Handles:** Perfect matches after cleaning
- **Range:** {0, 1}

### F07: `name_token_containment`
- **Computation:** |s1_tokens ∩ cand_tokens| / |s1_tokens|
- **Handles:** Truncated names (S1 words contained in candidate)
- **Range:** [0, 1]

### F08: `name_reverse_containment`
- **Computation:** |s1_tokens ∩ cand_tokens| / |cand_tokens|
- **Handles:** Extra words added to candidate
- **Range:** [0, 1]

### F09: `name_length_ratio`
- **Computation:** min(len(s1), len(cand)) / max(len(s1), len(cand))
- **Handles:** Length disparity detection
- **Range:** (0, 1]

### F10: `name_common_prefix_len`
- **Computation:** Length of longest common prefix (normalized)
- **Handles:** Same-starting businesses
- **Range:** [0, 1]

### F11: `name_sorted_token_jaccard`
- **Computation:** Jaccard on alphabetically sorted word tokens
- **Handles:** Word order shuffling
- **Range:** [0, 1]

### F12: `name_suffix_match`
- **Computation:** 1 if legal suffixes match, 0 if mismatch, -1 if one missing
- **Handles:** LLC vs Inc vs Corp disambiguation
- **Range:** {-1, 0, 1}

### F13: `name_domain_decoded_sim`
- **Computation:** If candidate is domain: normalized_lev(s1_concat, domain_base)
- **Handles:** Domain name matching
- **Range:** [0, 1] or NaN if not a domain
- **Note:** NaN when candidate is not a domain → LightGBM handles natively

### F14: `name_transliterated_sim`
- **Computation:** name_jaccard on transliterated versions
- **Handles:** Cross-script matching
- **Range:** [0, 1] or NaN if same script

### F15: `name_idf_weighted_overlap`
- **Computation:** Σ(IDF(token) for token in s1∩cand) / Σ(IDF(token) for token in s1∪cand)
- **Handles:** Rare word matches worth more than common word matches
- **Range:** [0, 1]

---

## Category 2: Address Similarity Features (12)

### F16: `addr_jaccard_token`
- **Computation:** Jaccard on address word tokens
- **Range:** [0, 1]

### F17: `addr_levenshtein_norm`
- **Computation:** Normalized Levenshtein on full address strings
- **Range:** [0, 1]

### F18: `addr_street_number_match`
- **Computation:** 1 if extracted street numbers match, 0 otherwise
- **Extraction:** First numeric token, e.g., "3315" from "3315 Fremont St"
- **Range:** {0, 1, NaN}

### F19: `addr_city_match`
- **Computation:** 1 if extracted city names match (after normalization)
- **Range:** {0, 1, NaN}

### F20: `addr_state_match`
- **Computation:** 1 if states match (after abbreviation expansion)
- **Range:** {0, 1, NaN}

### F21: `addr_zip_pin_match`
- **Computation:** 1 if ZIP/PIN codes match
- **Extraction:** 5-digit (US) or 6-digit (India) numbers
- **Range:** {0, 1, NaN}

### F22: `addr_token_overlap_count`
- **Computation:** |addr_tokens(s1) ∩ addr_tokens(cand)|
- **Range:** [0, ∞)

### F23: `addr_token_overlap_ratio`
- **Computation:** Overlap count / max(|s1_tokens|, |cand_tokens|)
- **Range:** [0, 1]

### F24: `addr_empty_indicator`
- **Computation:** 0=both present, 1=candidate empty, 2=both empty
- **Range:** {0, 1, 2}

### F25: `addr_number_match`
- **Computation:** Jaccard on all numeric tokens extracted from addresses
- **Handles:** Plot numbers, door numbers, flat numbers
- **Range:** [0, 1]

### F26: `addr_transliterated_sim`
- **Computation:** Token Jaccard after transliterating address (for India)
- **Handles:** राजस्थान ↔ Rajasthan in addresses
- **Range:** [0, 1]

### F27: `addr_tfidf_cosine`
- **Computation:** TF-IDF cosine on address text
- **Range:** [0, 1]

---

## Category 3: Cross/Meta Features (9)

### F28: `name_addr_interaction`
- **Computation:** name_jaccard_word × addr_jaccard_token
- **Handles:** Joint signal — high on both = very likely match
- **Range:** [0, 1]

### F29: `script_match`
- **Computation:** 1 if s1 and candidate use same script, 0 otherwise
- **Range:** {0, 1}

### F30: `is_domain_name`
- **Computation:** 1 if candidate name contains .com/.in/.org, 0 otherwise
- **Range:** {0, 1}

### F31: `sbert_cosine_sim`
- **Computation:** Cosine similarity between Sentence-BERT embeddings
- **Handles:** Semantic similarity beyond token overlap
- **Range:** [-1, 1]

### F32: `is_mixed_script`
- **Computation:** 1 if candidate has multiple scripts, 0 otherwise
- **Range:** {0, 1}

### F33: `candidate_source`
- **Computation:** 0 if S2, 1 if S3
- **Handles:** Source-specific noise patterns
- **Range:** {0, 1}

### F34: `name_addr_combined_tfidf`
- **Computation:** TF-IDF cosine on concatenated (name + " " + address)
- **Range:** [0, 1]

### F35: `bm25_score`
- **Computation:** BM25 score between S1 and candidate texts
- **Handles:** Term frequency saturation (better than raw TF-IDF for long texts)
- **Range:** [0, ∞)

### F36: `phonetic_name_match`
- **Computation:** 1 if Metaphone encodings match, partial match score otherwise
- **Handles:** Phonetically similar names with different spellings
- **Range:** [0, 1]
- **Library:** `jellyfish.metaphone()`

---

## Category 4: Embedding Features (4)

### F37: `sbert_l2_distance`
- **Computation:** L2 distance between Sentence-BERT embeddings
- **Range:** [0, ∞)

### F38: `sbert_dot_product`
- **Computation:** Dot product of normalized embeddings
- **Range:** [-1, 1]

### F39: `cross_encoder_score`
- **Computation:** Cross-encoder confidence for borderline cases
- **Range:** [0, 1]
- **Note:** Only computed for candidates with ensemble score 0.3-0.7

### F40: `name_addr_combined_cosine`
- **Computation:** TF-IDF cosine on name+address combined text
- **Range:** [0, 1]

---

## Feature Computation Strategy (Performance)

### Vectorized Batch Computation
```python
import numpy as np
from rapidfuzz import fuzz, process
from rapidfuzz.distance import Levenshtein, JaroWinkler

def compute_features_batch(s1_names, cand_names, s1_addrs, cand_addrs):
    n = len(s1_names)
    features = np.zeros((n, 40), dtype=np.float32)
    
    for i in range(n):
        # Name features (vectorized where possible)
        s1_tokens = set(s1_names[i].split())
        c_tokens = set(cand_names[i].split())
        
        intersection = len(s1_tokens & c_tokens)
        union = len(s1_tokens | c_tokens)
        
        features[i, 0] = intersection / union if union > 0 else 0  # jaccard
        features[i, 2] = Levenshtein.normalized_similarity(s1_names[i], cand_names[i])
        features[i, 3] = JaroWinkler.normalized_similarity(s1_names[i], cand_names[i])
        # ... etc
    
    return features
```

### Parallelization
```python
from joblib import Parallel, delayed

# Process in chunks of 100K pairs
chunk_size = 100000
all_features = Parallel(n_jobs=8)(
    delayed(compute_features_batch)(
        s1_names[i:i+chunk_size],
        cand_names[i:i+chunk_size],
        s1_addrs[i:i+chunk_size],
        cand_addrs[i:i+chunk_size]
    )
    for i in range(0, len(s1_names), chunk_size)
)
features = np.vstack(all_features)
```

---

## Expected Feature Importance (from similar ER tasks)

| Rank | Feature | Expected Importance |
|---|---|---|
| 1 | `name_tfidf_cosine` (F05) | Very High |
| 2 | `name_jaccard_char3gram` (F02) | Very High |
| 3 | `name_jaro_winkler` (F04) | High |
| 4 | `name_jaccard_word` (F01) | High |
| 5 | `sbert_cosine_sim` (F31) | High |
| 6 | `addr_jaccard_token` (F16) | High |
| 7 | `name_token_containment` (F07) | Medium-High |
| 8 | `name_levenshtein_norm` (F03) | Medium-High |
| 9 | `addr_state_match` (F20) | Medium |
| 10 | `name_transliterated_sim` (F14) | Medium |
| 11 | `name_domain_decoded_sim` (F13) | Medium |
| 12 | `addr_street_number_match` (F18) | Medium |
| 13 | `name_addr_interaction` (F28) | Medium |
| 14 | `script_match` (F29) | Medium |
| 15 | `addr_empty_indicator` (F24) | Low-Medium |

# Dataset Deep-Dive Analysis
## Amazon ML Challenge 2026 — Business Entity Resolution

---

## 1. Dataset Scale

| Dataset | Source 1 | Source 2 | Source 3 | Total Records |
|---|---|---|---|---|
| **Train** | 2,206,821 | 5,034,616 | 5,285,603 | 12,527,040 |
| **Test** | 1,732,544 | 4,887,273 | 5,082,316 | 11,702,133 |

## 2. Country Distribution

### Training Set
| Source | US | India |
|---|---|---|
| S1 | 1,323,633 (60%) | 883,188 (40%) |
| S2 | 3,016,817 (60%) | 2,017,799 (40%) |
| S3 | 3,170,056 (60%) | 2,115,547 (40%) |

### Test Set (NEW: France appears!)
| Source | India | US | France |
|---|---|---|---|
| S1 | 809,986 (46.7%) | 663,106 (38.3%) | 259,452 (15.0%) |
| S2 | 2,312,565 (47.3%) | 1,871,330 (38.3%) | 703,378 (14.4%) |
| S3 | 2,405,000 (47.3%) | 1,945,701 (38.3%) | 731,615 (14.4%) |

> **Critical:** France is 15% of test data but has ZERO training examples.

---

## 3. Ground Truth Statistics

| Metric | Value |
|---|---|
| Total S1 entities | 2,206,821 |
| Singletons (no match) | 123,247 (5.58%) |
| Matched entities | 2,083,574 (94.42%) |
| Total match IDs | 7,638,365 |
| Avg matches per matched entity | 3.67 |

### Match Count Distribution
| # Matches | Count | % |
|---|---|---|
| 0 (singleton) | 123,247 | 5.58% |
| 1 | 119,157 | 5.40% |
| 2 | 375,212 | 17.00% |
| 3 | 530,841 | 24.05% |
| 4 | 484,115 | 21.94% |
| 5 | 321,957 | 14.59% |
| 6 | 164,868 | 7.47% |
| 7 | 63,968 | 2.90% |
| 8 | 18,680 | 0.85% |
| 9 | 4,205 | 0.19% |
| 10 | 534 | 0.02% |
| 11 | 37 | 0.00% |

### S2 vs S3 Split
| Metric | Value |
|---|---|
| Total S2 match IDs | 3,693,619 |
| Total S3 match IDs | 3,944,746 |
| Entities with BOTH S2+S3 | 1,776,047 (85.2%) |
| Entities with only S2 | 143,029 (6.9%) |
| Entities with only S3 | 164,498 (7.9%) |
| Avg S2 matches per entity | 1.77 |
| Avg S3 matches per entity | 1.89 |

---

## 4. Distractor / Unmatched Records (CRITICAL!)

| Source | Matched | Total | % Matched | % Distractor |
|---|---|---|---|---|
| S2 | 3,693,619 | 5,034,616 | 73.4% | **26.6%** |
| S3 | 3,944,746 | 5,285,603 | 74.6% | **25.4%** |

> **~26% of S2/S3 records are DISTRACTORS** — they don't match any S1 entity.
> These will create false positives if your blocking is too aggressive.
> This makes precision even more critical for F0.5 scoring.

---

## 5. Address Analysis

### Address Emptiness
| Source | Country | Empty | Total | Rate |
|---|---|---|---|---|
| S1 | India | 0 | 883,188 | **0.0%** |
| S1 | US | 0 | 1,323,633 | **0.0%** |
| S2 | India | 57,846 | 2,017,799 | 2.9% |
| S2 | US | 111,121 | 3,016,817 | 3.7% |
| S3 | India | 64,948 | 2,115,547 | 3.1% |
| S3 | US | 110,968 | 3,170,056 | 3.5% |

- S1 **never** has empty addresses
- ~3-4% of S2/S3 have empty addresses
- "null" appears as literal text in 2.0% of S2/S3 addresses

### Name Length Statistics
| Source | Chars Median | Chars P90 | Words Median | Words P90 |
|---|---|---|---|---|
| S1 | 24 | 34 | 4 | 5 |
| S2 | 25 | 37 | 4 | 5 |
| S3 | 25 | 37 | 4 | 5 |

---

## 6. Script Distribution (Indian Records)

**S1 is 100% Latin script.** S2/S3 have significant non-Latin:

| Script | S2 India (%) | S3 India (%) |
|---|---|---|
| Latin | 77.5% | 88.0% |
| **Devanagari (Hindi)** | **12.7%** | **6.9%** |
| Telugu | 1.9% | 1.0% |
| Kannada | 1.8% | 0.9% |
| Tamil | 1.5% | 0.8% |
| Bengali | 1.5% | 0.8% |
| Gujarati | 1.5% | 0.7% |
| Malayalam | 0.9% | 0.4% |
| Gurmukhi (Punjabi) | 0.3% | 0.2% |

**Total non-Latin in S2 India: ~22.5%**
**Total non-Latin in S3 India: ~12.0%**

---

## 7. Comprehensive Noise Pattern Inventory

### 7A. Difficulty Distribution (by name token Jaccard similarity)
From 1,846 sampled matched pairs:

| Difficulty | % of Pairs | Jaccard Range | Description |
|---|---|---|---|
| **Easy** | **28.1%** | > 0.8 | Near-exact names (case, spacing) |
| **Medium** | **49.9%** | 0.4 - 0.8 | Partial overlap (missing suffix, truncation, single typo) |
| **Hard** | **7.3%** | 0.15 - 0.4 | Heavy typos, accented characters |
| **Extreme** | **14.7%** | < 0.15 | Cross-script, domains, DBA — ZERO word overlap |

### 7B. Complete Noise Catalog (from 3,713 analyzed pairs)

| # | Noise Type | Frequency | Severity | Examples |
|---|---|---|---|---|
| 1 | **Partial/reordered address** | 32.2% | Medium | `"24800 Euclid Avenue, OH"` ↔ `"OH, EUCLID AVE, EUCLID"` |
| 2 | **Name word order shuffle** | 18.0% | Low | `"Srp Advisors of Hyderabad"` ↔ `"Srp of Advisors Hyderabad"` |
| 3 | **Address-only matches** | 14.7% | Critical | Names have zero overlap, matched by address only (transliteration + domains) |
| 4 | **Accented characters** | 13.8% | Medium | `"Tránsalta"`, `"Fóundation"`, `"Pántages"` |
| 5 | **Truncated names** | 13.7% | Medium | `"AUK Pono L.L.C."` → `"AUK PONO"` (dropped "LLC") |
| 6 | **Extra words added** | 10.5% | Medium | `"Summit Health"` → `"Summit Health Corp"`, DBA prefixes like `"Tavozephdelta dba"` |
| 7 | **Completely different names** | 7.7% | Critical | Cross-script transliteration + domain names |
| 8 | **Cross-script transliteration** | 5.3% | Critical | Latin ↔ Devanagari/Tamil/Telugu/Kannada/Bengali/Gujarati/Malayalam/Gurmukhi |
| 9 | **Domain as business name** | 5.6% | Critical | `"Pcl Medical Centre"` ↔ `"pclmedicalcentre.com"` |
| 10 | **Missing address** | 5.2% | High | S2/S3 has completely empty address |
| 11 | **Number substitution (l33t)** | 2.2% | High | `"Indo 5ky Energy"` (5→S), `"C0rnerstone"` (0→O), `"Ava1on"` (1→L) |
| 12 | **"null" in address** | 2.0% | Medium | Literal "null" text in address field |
| 13 | **Prefix noise** | 0.8% | Low | `"-- Meyer and Garrett"`, `"*** rajkotatelier.com"` |
| 14 | **Mixed script** | 0.5% | High | `"Sun कंसल्टेंसी Private Limited"` — Latin + Devanagari in same name |

### 7C. Typo Edit Distance (Latin pairs only, 3,153 pairs)
| Category | Count | % |
|---|---|---|
| 0 edits (exact) | 529 | 16.8% |
| 1-2 edits (minor typo) | 501 | 15.9% |
| 3-5 edits (moderate typo) | 835 | 26.5% |
| 6+ edits (heavy rewrite) | 1,288 | 40.8% |

### 7D. Domain Name Pattern Analysis
Domain names are **concatenated business names** with suffixes stripped:
```
"Elevate Impex Private Limited" → "elevateimpex.com"     ✓ EXACT CONCAT
"Cardiology Metro Specialists Inc" → "cardiologymetrospecialists.com"  ✓
"Tullahoma Youth Fellowship Inc" → "tullah0mayouthfellowship.com"     ~ TYPO IN DOMAIN
"Saon Holding Company Clinic" → "shclinic.com"           ✗ ABBREVIATION
```

---

## 8. Singleton Analysis

### Singletons vs Matched Comparison
| Feature | Singletons (n=500) | Matched (n=500) |
|---|---|---|
| Name length median | 23 | 24 |
| Address length median | 40 | 43 |
| Has legal suffix | 59.2% | 57.6% |
| US / India split | 60% / 40% | 57% / 43% |

> Singletons are **indistinguishable** from matched entities by surface features.
> You CANNOT use a heuristic rule to identify them — only the absence of good candidates indicates a singleton.

---

## 9. France Test Data (Samples)

### S1 France Examples:
```
S1-156285671 | << Team Ecole | 175 Boulevard du Président Franklin Roosevelt, Bordeaux, Nouvelle-Aquitaine
S1-921369899 | ZNB Club SARL | 5 bis Rue Pierre Dignac, La Teste-de-Buch, Nouvelle-Aquitaine
S1-913506265 | Thermal & Fils SASU | 20 Rue Parmentier, Dunkerque, Hauts-de-France
S1-628750886 | Grain & Fils | 329 Avenue de Dunkerque, Lille, Hauts-de-France
```

### S2/S3 France Examples:
```
S2-566025912 | Marina Ecole France Sarl | 63 R. DE DIEPPE, LILLE
S2-158121477 | SCI Ptit Àmicale | 18 RUE JEN ZAY, Dunkerque, Nord
S3-198586129 | Fractales Amis Groupe S.A.S | 23 Rue Icmre, La Teste-de-buch, Gironde
S3-934627663 | Dunkerque Club | 13 Rue Jules Andrieu, Dunkerque
```

### French Patterns to Handle:
- Legal suffixes: SARL, SAS, SASU, SA, SCI, SNC, S.A.S, S.A.R.L
- Address keywords: Rue, Avenue, Boulevard, Allée, Place, Impasse, Chemin
- Region/department naming: Nouvelle-Aquitaine, Hauts-de-France, Gironde, Nord, Loire-Atlantique
- Common words: "& Fils" (& Sons), "Groupe", "Cie" (Company), "Frères" (Brothers)
- Accented characters: è, é, ê, ë, à, â, ô, û, ù, ç, î

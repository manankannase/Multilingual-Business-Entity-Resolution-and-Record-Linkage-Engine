> **Note:** Background reference only. Where this conflicts with `02_implementation_plan.md` (v2, final), 02 wins.

# Noise Pattern Correction Playbook
## Every Noise Type → Detection → Correction → Feature

---

## Noise #1: Cross-Script Transliteration (5.3% of pairs, CRITICAL)

**What it is:** S1 is always Latin script. S2/S3 Indian records may be in Devanagari, Tamil, Telugu, Kannada, Bengali, Gujarati, Malayalam, or Gurmukhi.

**Examples:**
```
S1: "Silver Foundation Private Limited"    →  S2: "सिल्वर फाउंडेशन प्राइवेट लिमिटेड"
S1: "Blue Management LLP"                 →  S3: "బ్లూ మేనేజ్‌మెంట్ ఎల్‌ఎల్‌పీ"
S1: "Raj Investments LLP"                 →  S2: "ராஜ் இன்வெஸ்ட்மெண்ட்ஸ் எல்எல்பி"
S1: "Super Software Private Limited"      →  S3: "ಸೂಪರ್ ಸಾಫ್ಟ್‌ವೇರ್ ಪ್ರೈವೇಟ್ ಲಿಮಿಟೆಡ್"
```

**Detection:**
```python
def detect_script(text):
    for ch in text:
        if ch.isalpha():
            name = unicodedata.name(ch, '')
            if 'DEVANAGARI' in name: return 'devanagari'
            if 'TAMIL' in name: return 'tamil'
            # ... 6 more scripts
    return 'latin'
```

**Correction:**
- Transliterate all non-Latin text to Latin using `aksharamukha` or `indic-transliteration`
- Store transliterated version as additional column
- Use BOTH original and transliterated for blocking and features

**Feature:**
- `transliterated_name_jaccard`: Jaccard between S1 name tokens and transliterated S2/S3 name tokens
- `transliterated_name_levenshtein`: Normalized Levenshtein on transliterated names
- `script_match_indicator`: 1 if same script, 0 if different

---

## Noise #2: Domain Names as Business Names (5.6%, CRITICAL)

**What it is:** Some S2/S3 records use a concatenated domain name instead of the actual business name.

**Examples:**
```
S1: "Pcl Medical Centre"           →  S3: "pclmedicalcentre.com"
S1: "Elevate Impex Private Ltd"    →  S2: "elevateimpex.com"
S1: "Tullahoma Youth Fellowship"   →  S3: "tullah0mayouthfellowship.com"  (with typo!)
```

**Detection:**
```python
def is_domain(name):
    return bool(re.search(r'\.(com|in|org|net|co|io|biz)\b', name.lower()))
```

**Correction:**
```python
def decode_domain(name):
    base = re.sub(r'\.(com|in|org|net|co|io|biz)(\s.*)?$', '', name.lower().strip())
    base = re.sub(r'^(www\.)', '', base)
    base = re.sub(r'[^a-z0-9]', '', base)
    return base

def s1_to_concat(name):
    # Strip legal suffixes and concatenate
    cleaned = strip_suffixes(name.lower())
    return re.sub(r'[^a-z0-9]', '', cleaned)
```

**Feature:**
- `domain_decoded_similarity`: normalized Levenshtein between `s1_to_concat(s1_name)` and `decode_domain(cand_name)`
- `is_domain_indicator`: 1 if candidate name contains .com/.in etc.

---

## Noise #3: Accented Characters (13.8%)

**What it is:** Random accent marks added to characters.

**Examples:**
```
"Tucker Metro Tránsalta"    (á instead of a)
"Silver Fóundation Private" (ó instead of o)  
"Dibona Pántages"           (á instead of a)
"Payne Énterprises"         (É instead of E)
```

**Correction:**
```python
import unicodedata

def strip_accents(text):
    nfkd = unicodedata.normalize('NFKD', text)
    return ''.join(c for c in nfkd if not unicodedata.combining(c))
```

**Feature:** Applied during normalization — no separate feature needed. All similarity features benefit from accent stripping.

---

## Noise #4: L33t-Speak Number Substitution (2.2%)

**What it is:** Letters replaced by visually similar digits.

**Examples:**
```
"Indo 5ky Energy"          (5 → S)
"C0rnerstone Summit"       (0 → O)
"Ava1on-Vidyalaya"         (1 → L)
"Ro1ston Supreme"          (1 → L)
"tullah0mayouthfellowship" (0 → O, in domain!)
```

**Correction:**
```python
LEET_MAP = {'0': 'o', '1': 'l', '3': 'e', '4': 'a', '5': 's', '7': 't'}

def leet_decode(text):
    result = []
    for i, ch in enumerate(text):
        if ch in LEET_MAP:
            before = i > 0 and text[i-1].isalpha()
            after = i < len(text)-1 and text[i+1].isalpha()
            if before or after:
                result.append(LEET_MAP[ch])
                continue
        result.append(ch)
    return ''.join(result)
```

**Feature:**
- `leet_decoded_similarity`: Similarity after l33t decoding
- Applied during normalization for all features

---

## Noise #5: Name Truncation / Missing Words (13.7%)

**What it is:** Legal suffixes or descriptive words dropped from name.

**Examples:**
```
S1: "AUK Pono L.L.C."              →  "AUK PONO"            (dropped LLC)
S1: "Shreyans Holdings Associates"  →  "Shreyans Holdings"   (dropped Associates)
S1: "All Logistics Pvt Ltd"         →  "All Logistics Pvt"   (dropped Ltd)
```

**Correction:** No text correction needed — handled by features.

**Features:**
- `token_containment_ratio`: |S1_tokens ∩ Cand_tokens| / |S1_tokens|
- `reverse_containment`: |S1_tokens ∩ Cand_tokens| / |Cand_tokens|
- `missing_tokens_count`: |S1_tokens - Cand_tokens|
- `suffix_stripped_jaccard`: Jaccard after removing legal suffixes from both

---

## Noise #6: Extra Words Added (10.5%)

**What it is:** Additional words prepended/appended — often DBA names or legal suffixes.

**Examples:**
```
S1: "Perfect Technology Pvt Ltd" →  "Tavozephdelta dba Perfect Technology Pvt Ltd"
S1: "Summit Health"              →  "Summit Health Corp"
S1: "Pali Energy Associates"     →  "-- Pali Energy Associates Corporation"
```

**Correction:**
```python
# Strip DBA prefixes
name = re.sub(r'^.*?\bdba\b\s*', '', name, flags=re.IGNORECASE)
# Strip prefix garbage
name = re.sub(r'^[\-\*\#\<\>]+\s*', '', name)
```

**Features:**
- `token_containment_ratio`: Already handles this
- `extra_tokens_count`: |Cand_tokens - S1_tokens|
- `dba_indicator`: 1 if "dba" appears in candidate name

---

## Noise #7: Name Word Order Shuffle (18.0%)

**What it is:** Same words, different order.

**Examples:**
```
S1: "Srp Advisors of Hyderabad"  →  "Srp of Advisors Hyderabad"
S1: "Womens Health United Care"   →  "United Care Womens Health"
```

**Correction:** No text correction — handled by order-invariant features.

**Features:**
- `sorted_token_jaccard`: Sort tokens alphabetically, then compare
- `token_set_jaccard`: Already order-invariant
- `sorted_name_exact_match`: 1 if sorted tokens are identical

---

## Noise #8: Address Reordering and Partial Addresses (32.2%)

**What it is:** Address components shuffled, abbreviated, or missing.

**Examples:**
```
S1: "24800 Euclid Avenue, Euclid, OH"  →  "OH, EUCLID AVE, EUCLID"
S1: "3682 Ravens Glen Drive, Columbus, OH"  →  "RAVENS GLEN DR, COLUMBUS, OH"
S1: "F-25, Asha Complex, Sec-18, Lucknow, UP"  →  "F-25, LUCKNOW HQ REGION, UP"
```

**Correction:**
```python
def normalize_address(addr):
    addr = addr.lower()
    addr = re.sub(r'\bnull\b', '', addr)
    # Expand abbreviations
    for abbr, full in STREET_ABBREVS.items():
        addr = re.sub(rf'\b{abbr}\b', full, addr)
    # Expand state abbreviations
    for abbr, full in STATE_ABBREVS.items():
        addr = re.sub(rf'\b{abbr}\b', full, addr)
    return addr
```

**Features:**
- `addr_token_jaccard`: Order-invariant token overlap
- `street_number_match`: Extract and compare numbers
- `city_match`: Extract and compare city names
- `state_match`: Extract and compare state (after abbreviation expansion)
- `zip_pin_match`: Extract and compare postal codes

---

## Noise #9: Missing Address (5.2% of S2/S3)

**What it is:** S2/S3 record has completely empty address. S1 always has an address.

**Correction:** Cannot be corrected — must rely on name-only matching.

**Features:**
- `addr_both_present`: 1 if both have addresses, 0 otherwise
- `addr_candidate_empty`: 1 if candidate has no address
- When address is empty, address features default to NaN → LightGBM handles natively

---

## Noise #10: "null" in Address (2.0%)

**What it is:** Literal text "null" appears where a component is missing.

**Examples:**
```
"3315 FREMONT ST, null, PEORIA, IL"
"630 45ND TERRACE, null, KANSAS CITY, MO"
```

**Correction:**
```python
addr = re.sub(r'\bnull\b', '', addr, flags=re.IGNORECASE)
addr = re.sub(r',\s*,', ',', addr)  # Clean up double commas
```

---

## Noise #11: Prefix Garbage (0.8%)

**What it is:** Names prefixed with dashes, asterisks, or symbols.

**Examples:**
```
"-- Meyer and Garrett Ethereum"
"*** rajkotatelier.com"
"-- Pali Energy Associates Corporation"
```

**Correction:**
```python
name = re.sub(r'^[\-\*\#\<\>\+]+\s*', '', name)
```

---

## Noise #12: Mixed Script (0.5%)

**What it is:** Single name contains both Latin and non-Latin characters.

**Examples:**
```
"Sun कंसल्टेंसी Private Limited"     (Latin + Devanagari)
"जय White इंफोटेक Limited"          (Devanagari + Latin)
"Digital टेक्नोलॉजी प्राइवेट लिमिटेड"  (Latin + Devanagari)
```

**Correction:**
```python
def handle_mixed_script(name):
    # Split into Latin and non-Latin parts
    # Transliterate non-Latin parts
    # Combine all as Latin
    latin_parts, nonlatin_parts = split_by_script(name)
    translit_parts = [transliterate(p) for p in nonlatin_parts]
    return ' '.join(latin_parts + translit_parts)
```

**Feature:**
- `is_mixed_script`: 1 if candidate has multiple scripts
- All similarity features computed on the combined transliterated form

---

## Noise #13: French Patterns (Test Only — 15% of test)

**What it is:** French business names and addresses with French-specific patterns.

**Suffixes:** SARL, SAS, SASU, SA, SCI, SNC, EURL, S.A.S, S.A.R.L
**Address:** Rue, Avenue, Boulevard, Allée, Place, Impasse
**Common words:** & Fils, Groupe, Cie, Frères

**Correction:**
```python
FRENCH_SUFFIXES = {
    'sarl': 'sarl', 's.a.r.l.': 'sarl', 's.a.r.l': 'sarl',
    'sas': 'sas', 's.a.s': 'sas', 's.a.s.': 'sas',
    'sasu': 'sasu', 's.a.s.u.': 'sasu',
    'sa': 'sa', 's.a.': 'sa', 's.a': 'sa',
    'sci': 'sci', 's.c.i.': 'sci',
    'snc': 'snc', 'eurl': 'eurl', 'e.u.r.l.': 'eurl',
}

FRENCH_ADDR_ABBREVS = {
    'r': 'rue', 'r.': 'rue', 'av': 'avenue', 'av.': 'avenue',
    'bd': 'boulevard', 'bd.': 'boulevard', 'pl': 'place',
    'all': 'allee', 'imp': 'impasse', 'ch': 'chemin',
}
```

---

## Summary: Noise Impact vs Correction Difficulty

| Noise | Frequency | Score Impact | Correction Difficulty | Priority |
|---|---|---|---|---|
| Cross-script transliteration | 5.3% | +0.05 F0.5 | Medium (need library) | **P0** |
| Domain names | 5.6% | +0.02 | Easy (regex) | **P0** |
| Accented characters | 13.8% | +0.03 | Easy (unicode) | **P0** |
| Address partial/reorder | 32.2% | +0.04 | Medium (parsing) | **P0** |
| Name truncation | 13.7% | +0.02 | Easy (features) | P1 |
| Extra words / DBA | 10.5% | +0.01 | Easy (regex) | P1 |
| Word order shuffle | 18.0% | +0.01 | Easy (sorted tokens) | P1 |
| L33t-speak | 2.2% | +0.01 | Easy (map) | P1 |
| Missing address | 5.2% | +0.005 | N/A (feature design) | P2 |
| "null" in address | 2.0% | +0.005 | Easy (regex) | P2 |
| Prefix garbage | 0.8% | +0.002 | Easy (regex) | P2 |
| Mixed script | 0.5% | +0.002 | Medium (split+translit) | P2 |
| French patterns | 15% test | +0.01 | Easy (suffix maps) | P1 |

# Amazon ML Challenge 2026 — Business Entity Resolution: v1 hand-off

**Status (25 Sep 2026):** v1 submitted → **public LB F0.5 = 0.966** (our validation said 0.9744).
Leaderboard top = 0.989. v2 is running (fixes + stage-2 context model), see "Where we are going".

---

## 1. The task in 5 lines
- For every Source-1 (S1) business record, return all Source-2/3 (S2/S3) records that are the same business.
- Fields: `entity_id`, `business_name`, `business_address`, `country`. Test: 1.73M S1 vs 9.97M S2+S3.
- Metric: **macro F0.5 per S1** (precision weighted 2×). S1 with no true match scores 1.0 only if we predict nothing.
- Countries: train US + India; **test adds France** (15%) with no training labels.
- Rules: no external data/lookups; models MIT/Apache-2.0 ≤ 8B params. Deliverables: `matching_results.tsv`
  (scored), `candidate_pairs.tsv`, code zip, filled `Documentation_template.md`. Deadline **27 Sep 23:59 IST**.

## 2. Data facts that drive the design (measured on train)
| Fact | Number | Consequence |
|---|---|---|
| Each S2/S3 record matches **≤ 1** S1 | 0 of 7.64M linked twice | keep each S2/S3 only for its best S1 ("one-to-one") |
| Matches never cross countries | 0% | search within country |
| S1 with no match | 5.6% | need a reliable "no match" |
| Matches per S1 | mean 3.46 (0–11) | many-match, recall per S1 matters |
| 49% of S1 share their cleaned name with another S1 | — | **address decides**, name alone is useless |
| Indic-script S2/S3 names (Hindi, Telugu, Tamil, …) | ~7% of true pairs | they are word-by-word translations → learned dictionary |
| Unmatched S2/S3 (decoys) | 26% train; more in test | be conservative |

Noise: word shuffles, typos/l33t (`5ky`), brackets and junk prefixes (`<<`, `##`), legal suffix swaps
(`Pvt Ltd`, `P.L.L.C.`), domain-style names (`raabmoderntreasury.com`), `dba`, state name vs code, address
parts reordered, house numbers zero-padded / changed, `null` in addresses, empty addresses (~3%).

## 3. Pipeline (code in `code/business_entity_resolution/src/`)
```
TSV ─► prep.py (normalise 24M records) ─► blocking.py (candidates) ─► features.py (pair features)
    ─► pipeline.py fit (LightGBM) ─► decide.py (one-to-one + threshold) ─► matching_results.tsv
                                   └► stage2.py (context model, v2, in progress)
```
| File | What it does |
|---|---|
| `config.py` | paths (env vars `BER_DATA_DIR`, `BER_WORK_DIR`, `BER_OUT_DIR`), `N_JOBS`, `N_PROCS` |
| `data.py` | TSV → parquet cache |
| `text.py` | name/address normalisation: legal-form canon, l33t, dba, domains, accents, Indic transliteration, country-aware state parsing (US/IN/FR incl. French départements), street-type canon, house/street/city/PIN parse |
| `translit.py` | learns Indic→Latin token dictionary **from train pairs only** (e.g. राजस्थान→rajasthan) |
| `prep.py` | parallel normalisation → `work/norm/*.parquet` (~5 min) |
| `blocking.py` | char-3gram TF-IDF top-k per **(country, state)** partition: forward (S1→pool: name k10, addr k15, name+street+city k20), **reverse** (pool→S1 k3, strongest leg), orphan (no-state pool→all S1 by name k5) |
| `features.py` | ~55 rapidfuzz / token / number / state / legal features per pair |
| `pipeline.py` | `candidates`, `features`, `fit`, `predict` commands; train/val = **whole states** |
| `decide.py` | one-to-one assignment, threshold sweep, TSV writers |
| `metric.py` | exact macro F0.5 |
| `context.py`, `stage2.py` | v2: context features over the candidate graph + second LightGBM + expected-F0.5 rule |
| `run_v2.sh` | resumable end-to-end runner |

## 4. v1 results
| Item | Value |
|---|---|
| Blocking recall (val) | 97.34% of true pairs at ~40 candidates/S1 |
| LightGBM (1412 trees, logloss 0.00837) | val macro F0.5 **0.9744** @ threshold 0.74 |
| **Public leaderboard** | **0.966** |
| Test predictions | 3.30 matches/S1, 5.9% empty (France 3.43 / 5.1%, similar to train) |
| Top features | reverse-search rank & similarity, number containment, orphan rank, address containment, name Jaro-Winkler |

`model_v1/` has the v1 LightGBM model (`lgb_v1.txt`, features + threshold in `lgb_v1.json`) and the learned
Indic dictionary.

## 5. How to run (Windows, Python 3.11)
```
pip install -r code/business_entity_resolution/requirements.txt
cd code/business_entity_resolution/src
set BER_DATA_DIR=<...>/student_resource/dataset
set BER_WORK_DIR=<scratch, ~30 GB free>
set BER_OUT_DIR=<output dir>
python translit.py
python prep.py train test
python pipeline.py candidates train      # ~30 min
python pipeline.py candidates test       # ~65 min (France 7, India 41, US 16)
python pipeline.py features train        # exit code 3 = "more chunks", re-run until exit 0 (run_v2.sh loops)
python pipeline.py features test         # ~60 min
python pipeline.py fit
python pipeline.py predict               # writes matching_results.tsv + candidate_pairs.tsv
python stage2.py fit && python stage2.py predict     # v2 context model (optional)
```
**Memory (16 GB laptop):** Windows + apps already use ~8 GB. Close editors with AI language servers
(Windsurf/Codeium ate 4 GB). Everything is chunked / per-country / resumable because of this.

## 6. Why LB (0.966) < validation (0.9744) and why the leader is at 0.989
1. **Blocking ceiling**: 2.7% of true pairs never become candidates → caps recall. Leader likely has ~99%+.
2. **Validation was optimistic in v1**: random S1 sample ⇒ incomplete S1-vs-S1 competition; test has more
   decoys (5.8 vs 4.7 S2/S3 per S1). v2 validation uses whole states (fixed).
3. **v1 had an Indic transliteration bug** (tokens with punctuation, e.g. `दिल्ली,`, missed the dictionary) → many
   Indian candidates lost their state → missed. Fixed in v2 (India orphan share 8.3% → 3.4%).
4. France untested (no labels) — our predictions look statistically like train, but unknown.

## 7. Where we are going (next steps — pick one each)
| Priority | Idea | Expected gain | Owner |
|---|---|---|---|
| 1 | **v2** (running): translit fix, whole-state validation, faster blocking → val recall 97.7% | + | laptop |
| 2 | **Stage-2 context model** (`stage2.py`): competition between S1s, S2↔S3 agreement, rank gaps | ++ | laptop |
| 3 | **GPU dense blocker**: fine-tune small Apache/MIT encoder (arctic-embed-xs / multilingual-e5-small) on train pairs, add as extra blocking leg (public repo SABER: India recall@20 0.835→0.992) | +++ recall | GPU teammate |
| 4 | Remaining misses: empty-address candidates with common names; more orphan k; name+city exact keys | + | |
| 5 | France-specific checks (addresses `R.`/`Bd`, legal forms SAS/SARL/SCI), pseudo-labels | ? | |
| 6 | Final package: zip + `Documentation_template.md` (methodology) | required | anyone |

Full history, numbers and decisions: `docs/SESSION_LOG.md`; plan and research: `docs/PLAN.md`;
competitor write-ups (ideas only, no code copied): `research/`; EDA/experiment scripts: `eda/`.

# Amazon ML Challenge 2026 — Session Log

Running log of every working session: what we did, what we learned, what's next.
Newest session at the bottom. Plan lives in [PLAN.md](PLAN.md).

**Challenge:** Business Entity Resolution (S1 reference ↔ S2/S3 matches), metric = macro F0.5 per S1 entity.
**Hackathon window:** 25 Sep 2026 00:00 IST → 27 Sep 2026 23:59 IST.
**Data:** `6ab10eb3b23ba_student_resource/student_resource/` (README.md there = full problem statement).
**Machine:** 16 cores, 15.7 GB RAM, no CUDA GPU (Intel Iris Xe), Python 3.11, pandas 3.0.1, sklearn 1.7.2.

---

## Session 1 — 25 Sep 2026

**Done**
- Read the Unstop challenge page + problem-statement page (round 1593683).
- Confirmed dataset already downloaded & extracted locally.
- Row counts: train S1 2.21M / S2 5.03M / S3 5.29M; test S1 1.73M / S2 4.89M / S3 5.08M. Total ~2.4 GB TSV.
- Key rules noted: no external lookups (geocoding/APIs/web data), model must be MIT/Apache-2.0 and ≤8B params,
  France appears only in test, submit `matching_results.tsv` (scored) + `candidate_pairs.tsv` (audited) + code zip + methodology doc.
- Created this log and PLAN.md (research-backed plan).

**EDA findings** (scripts in `eda/`)
- Singletons 5.6%; mean 3.46 matches/S1 (mode 3, max 11); S2 per S1 0–5, S3 per S1 0–6.
- **Every S2/S3 id links to at most one S1** → enforce 1-to-many assignment.
- 26% of train S2/S3 are unmatched distractors; test has more S2/S3 per S1 (5.8 vs 4.7) → likely more distractors.
- 0% cross-country pairs → block within country. Test adds France (15% of test S1).
- Exact name eq only 10.7%, exact addr eq 7.2% → need fuzzy matching.
- ~7% of true pairs have non-Latin S2/S3 names (Devanagari, Telugu, Kannada, Tamil, Bengali, Gujarati, Malayalam);
  those still share an address token 99.8% of the time.
- Latin pairs share ≥1 cleaned name token 91%; share an address number ~80%; name-token OR number overlap 97.5%.
- Noise: word shuffles, char typos, brackets, junk prefixes (<< -- >> ##), legal-suffix swaps, domain-form names,
  state name vs code, address component reorder, number padding/suffix noise, empty addresses (~3%).
- Libraries present: pandas 3.0.1, pyarrow, sklearn 1.7.2, torch 2.11, sentence-transformers.
  Missing: rapidfuzz, lightgbm, anyascii, sparse_dot_topn.

**Research** — Sparkly (TF-IDF top-k blocking), ING sparse_dot_topn, pre-trained embeddings for ER (PVLDB'23),
Ditto (PVLDB'20), multilingual-e5-small (Apache-2.0), anyascii (ISC) / indic-transliteration (MIT). Details in PLAN.md §2.

**Decisions**
- Pipeline: normalise → union-of-blockers (TF-IDF name/address + exact keys, per country) → rapidfuzz features →
  LightGBM → context features → 1-to-many assignment + F0.5-tuned thresholds.
- Will NOT look at other teams' public GitHub repos for this challenge (fair-play/plagiarism risk).

**Competitive intel** (user asked to study other teams' public work)
- Checked rules: only external *data lookup* is banned; no clause on reading public code. Decision: read write-ups
  for ideas, **copy no code** (review/plagiarism risk). Downloaded docs into `research/`.
- Aamod007 (DataResolvers): blocking recall 96.3% @ 113 cands/S1, XGBoost, 27 features, val F0.5 0.965 (small pool,
  optimistic). = benchmark to beat.
- Sanyam2005 plan docs: best insights. Verified ourselves (`eda/verify.py`): 49% of S1 share a name key with another
  S1 (address is key); Indic names word-by-word aligned (99.99%), learned dictionary 99.97% coverage / 96.6% acc.
- Other repos: scaffolds or README only.
- PLAN.md updated with §2b (intel + 7 plan upgrades).

**Next**
- Install rapidfuzz, lightgbm, anyascii, sparse_dot_topn.
- Convert TSVs → parquet; implement metric + normalisation v1; blocking v1 with recall report.
- Get a first leaderboard submission today.

### Session 1 (cont.) — build started
- Compute decision: laptop for CPU pipeline, Colab Free (T4) only for GPU jobs (embeddings / GPU GBDT). PLAN §5b.
- Installed: rapidfuzz 3.14.6, lightgbm 4.7.0, anyascii, sparse_dot_topn 1.2.0, polars 1.44.2.
- Code in `submission/code/business_entity_resolution/src/`:
  - `config.py` paths (env overridable) · `data.py` TSV→parquet cache (`work/raw`) · `metric.py` (README example = 0.714 ✓)
  - `text.py` name/address normalisation (legal canon, l33t, dba, domain, junk, accents, state maps US/IN/FR,
    street-type canon, ordinals, zero-strip, house/street/city/state/PIN parse)
  - `translit.py` learned Indic→Latin dictionary from train pairs (1,363 entries; names by alignment,
    address tokens by co-occurrence; e.g. राजस्थान→rajasthan, प्राइवेट→private) → `work/indic_dict.json`
  - `prep.py` parallel normalisation of all 24.2M records → `work/norm/*.parquet` (6.5 min total).
- **Decision (user):** today = CPU-only pipeline on laptop; **tomorrow (26 Sep) user shares a lab GPU** → plan GPU
  upgrades then (multilingual embedding blocker for hard residue; possibly a cross-encoder re-ranker). Need: GPU model,
  VRAM, RAM, access method.
- Written (untested end-to-end yet): `blocking.py` (TF-IDF char-3gram views name/addr/name_addr, sample-fit +
  parallel transform, sparse_dot_topn top-k), `features.py` (~45 rapidfuzz/token/number features, ~29k pairs/s),
  `decide.py` (one-to-one, threshold sweep, TSV writer), `pipeline.py` (candidates → features → fit → predict).
- Blocking experiment (`eda/block_exp.py`, 20k val S1 vs full pool) running; first OOM fixed by column pruning.

### Session 1 (cont.) — blocking iterations
- **Blocking exp v1** (global top-k TF-IDF, 20k val S1 vs full pool): name@30 59.7%, addr@30 85.9%,
  name_addr@30 93.2%, UNION@30 **96.75%** (77 cands/S1). Misses: 33% empty cand address, 20% Indic name + short addr.
- Timing: global matmul far too slow (50k queries = 1229s/view → ~12 h/view on test) → **partition by (country, state)**.
- Fixed state bugs: US OR/UT/CT were mapped to Indian codes; India had 378 fake "states". Now country-aware maps,
  FR départements→regions (Nord, Pas-de-Calais→hdf; Gironde→naq; Loire-Atlantique→pdl), state groups tg≈ap, dc≈wa,
  missing pool state inferred from city (learned city→state table). Orphans (no state): US 3.6%, India 8.3%.
- Blocking v2 (`blocking.run_country`): forward per state (name k10, addr k15, name_addr k20), reverse per state
  (pool→S1 name_addr k3), orphan pool→all-country S1 by name k5. US view timings: addr 44s, name 1053s (orphans),
  name_addr 411s.
- **Memory:** OS already uses ~8 of 15.7 GB. Jobs got killed by Claude Code's low-memory reaper 2×. Fixes: prep
  returns columnar chunks (not dicts), per-country lazy loading (`prep.scan_norm`), N_PROCS=8 processes,
  free matrices per view, per-country shards (resumable), features written as shards, float32 for LightGBM.
- User: "don't ask to rerun — watch memory and run yourself" (saved to memory).
- Now running: `pipeline.py candidates train` (150k train + 50k val S1) → `candidates test`.
- **Blocking v2 result (val 50k S1): recall 97.34% @ 40.0 cands/S1** (v1 was 96.75% @ 77; public best 96.3% @ 113).
  Per blocker: reverse name_addr 91.6%, forward name_addr 91.1%, addr 83.2%, name 71.4%, orphan name 4.5%.
  Train/val candidate build: India 31 min, US ~35 min. Memory fix #3: slice-wise transform with short-lived
  worker pools, N_PROCS=6.
- Miss analysis (4,601 missed): 76% candidate had no state → **bug**: `to_latin` split only on spaces, so
  `दिल्ली,` (with comma) missed the dictionary; single-word Indic states (পশ্চিমবঙ্গ→bengal, தமிழ்நாடு→nadu) not
  recognised. Fixed (punctuation-aware split + state-word expansion) + Indic legal abbreviations (प्रा. लि.).
  44% of misses: empty-address candidate with a very common name (inherently ambiguous; low priority).
- Plan: v1 = current (buggy-translit) candidates → first submission; then re-prep + rebuild candidates for v2.

### Session 1 (cont.) — v1 model
- Blocking restructured again for memory: pool vectorised **per state partition** (never whole-country matrix),
  per-view results spilled to disk + streaming merge, recycled worker pool (maxtasksperchild).
- Test candidates: France 11.4M pairs (19 min), India 34.9M (124 min — addr 42 min, name_addr 58 min: slow!),
  US 26.0M (19 min). Total **72.3M pairs, 41.7/S1**. Test features: 72.3M pairs in 44 min.
- **LightGBM v1** (150k train S1 / 50k val S1, ~55 features, 1412 iters, logloss 0.00837):
  **val macro F0.5 = 0.9744 @ threshold 0.74** (blocking recall ceiling 97.34%). Sweep flat 0.66–0.80.
  Top features: rk_r_name_addr (reverse rank), sim_r_name_addr, num_cont_ba, rk_o_name, a_cont_ba, n_concat_jw.
- predict OOM'd (15 GB alloc loading all test features) → rewritten to score feature shards one by one,
  keep p≥0.3, candidate_pairs.tsv written per country.
- **v1 SUBMISSION FILE READY** (validator PASS): `submission/output/matching_results.tsv` (copy in `work/v1/`).
  Test preds: mean 3.30 matches/S1, 5.9% empty (France 3.43/5.1%, India 3.21/6.2%, US 3.35/5.8%) — France looks
  consistent with train (3.46/5.6%). User to upload to portal & report LB score.
- v2 started (chain in `work/v2_run.log`): re-prep with translit fix → candidates → features → fit → predict.
  Changes: addr/name_addr TF-IDF max_df 0.05→0.01 (speed), **train/val = whole states** (val: US me,ri,pa,nv,nh,sc,ak
  + India ar,as,jh,cg,dd,uk,br = 60k S1; train 26 states = 143k S1) so S1-vs-S1 competition is complete like on test;
  partitions without query S1 skipped; deterministic subset selection (sorted countries).
- `context.py`: stage-2 context features (within-S1 rank/gap/count, cross-S1 claims/margin, agreement with top
  candidate) + expected-F0.5 decision. On v1 val, expected-F0.5 = 0.9737 < threshold 0.9744 → keep threshold for now.
- User asked to re-check others' work before submitting. Scanned 117 public repos (READMEs in `research/readmes/`):
  none reports a leaderboard score. Only **SABER** (yogeshwars-cys) has numbers: GPU fine-tuned arctic-embed-xs
  (Apache-2.0) dense blocker + char-trigram + key legs, both directions; recall US 0.998 @24.8/S1, India 0.990 @29.1
  — but on a "2.5% world" (55k queries vs 258k pool, far fewer distractors than our full 10M pool). No selector yet.
  → Recommendation given: **submit v1 now** (validator PASS, val 0.9744 on realistic full-pool setup).
  → Tomorrow (lab GPU): fine-tune small MIT/Apache embedding (arctic-embed-xs / multilingual-e5-small) as extra
    dense blocking leg, esp. India.
- v2 train/val candidates: **val recall 97.70%** (train 98.13%) @ 39.7/S1 (v1 97.34%). name leg 71%→83% after translit fix.
  India train candidates 6 min (was 31).
- Code zip for portal: `submission/code_v1.zip` (+ README.md, pinned requirements.txt). Upload = matching_results.tsv
  (+ code zip if portal requires). candidate_pairs.tsv only in final package.
- `stage2.py` written: OOF stage-1 (2 state folds) → context features (p ≥ 0.01 pairs) → stage-2 LightGBM →
  threshold vs expected-F0.5 on val. `pipeline.predict` now keeps p ≥ 0.01 so stage 2 reuses test scores.
- v2 test candidates: France 12.2M (7 min, v1 19), India 35.4M (41 min, v1 124), US 27.3M (16 min) → **74.9M, 43.2/S1**.
- Memory incidents during v2 features: (a) Windsurf language server grew back to 2.6 GB → user ended it;
  (b) features loaded whole 10M pool before filtering → lazy scan filter; (c) 1M-pair chunks ~4-5 GB of Python
  sets → 250k chunks; (d) memory still crept up across chunks in one process → reaper kill #6. Fix: features are
  **resumable + process recycled every 6 chunks** (exit code 3 → re-invoke). Runner: `work/run_v2.sh`.
- v1 upload: user uploading via portal (slow upload, 96 MB). Browser tool can't upload >10 MB files.

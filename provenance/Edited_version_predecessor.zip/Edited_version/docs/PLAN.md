# Amazon ML Challenge 2026 — Business Entity Resolution: Master Plan

> Living document. Update when the approach changes; log day-to-day progress in [SESSION_LOG.md](SESSION_LOG.md).
> Deadline: **27 Sep 2026, 23:59 IST** (internal freeze: 27 Sep 18:00 IST).

---

## 0. Problem in one paragraph

For every Source-1 (S1) business record, return the set of Source-2/Source-3 (S2/S3) records that describe the same
real-world business. Fields: `entity_id`, `business_name`, `business_address`, `country`. Score = **macro F0.5 per S1
entity** (precision weighted 2x; a correctly empty prediction on a singleton = 1.0, any prediction on a singleton = 0.0).
Outputs: `matching_results.tsv` (scored), `candidate_pairs.tsv` (blocking set, audited), code zip, methodology doc.
Rules: **no external data/APIs** (no geocoding, registries, web lookups); any model **MIT/Apache-2.0, ≤ 8B params**.

---

## 1. What the data tells us (EDA, Session 1)

| Fact | Number | Consequence |
|---|---|---|
| Train S1 / S2 / S3 | 2.21M / 5.03M / 5.29M | Big — must be memory-lean (15.7 GB RAM, no GPU) |
| Test S1 / S2 / S3 | 1.73M / 4.89M / 5.08M | Test has **more S2/S3 per S1** (5.8 vs 4.7) → likely more distractors → be conservative |
| Countries (train) | US 60%, India 40% | — |
| Countries (test) | India 47%, US 38%, **France 15%** | France unseen → country-agnostic features + French normalisation + pseudo-labels |
| Singletons (S1 with no match) | **5.6%** | Small but each is worth a full 1.0 → need a calibrated "no match" decision |
| Matches per S1 | mean 3.46, mode 3, max 11 | Many-match regime: recall per entity matters too |
| S2 per S1 / S3 per S1 | 0–5 / 0–6 | Sources can hold several duplicates of the same business |
| **Each S2/S3 record matches ≤ 1 S1** | 0 of 7.64M linked twice | **Hard constraint** → assign every S2/S3 id to at most one S1 (argmax) |
| Unmatched S2/S3 (distractors) | 2.68M of 10.3M (26%) | Distractors look like real businesses (hard negatives) |
| Cross-country matches | 0% | Block strictly within country |
| Exact name / exact address equality | 10.7% / 7.2% | Exact-key rules alone are useless; fuzzy matching needed |
| Non-Latin S2/S3 names (Devanagari, Telugu, Kannada, Tamil, Bengali, Gujarati, Malayalam) | ~9% of India+ records; 7.3% of true pairs | Transliterate; rely on **address** for these (99.8% share an address token) |
| Latin pairs sharing ≥1 cleaned name token | 91% | Word-level blocking ok, char n-grams to catch typos |
| Pairs sharing an address number | ~80% | House/plot numbers are strong but noisy ("161" vs "519" happens) |
| Name OR address-number overlap | 97.5% | Union-of-blockers can reach high recall |

**Noise catalogue (seen in samples):**
- Names: word shuffles ("Cream lce Little"), char typos/OCR-like (`5ervices`, `lce`, `Treoasubr,y`), bracket wrapping
  (`[Ice]`, `(PUCKETT)`), junk prefixes (`<<`, `--`, `>>`, `##`), legal suffix add/drop/reorder (`LLC Raab…`,
  `P.L.L.C.`), domain form (`raabmoderntreasury.com`), dropped words (`OX Heritage`), extra generic words
  (`… Service`), Indic-script transliteration (`લક્ષ્મી સર્વિસીસ લિમિટેડ` = Lakshmi Services Limited), casing.
- Addresses: component reordering (`IA, Iowa City, 1064 Newton Rd`), abbreviations (`Rd/Road`, `St/Street/Saint`,
  French `R./Rue`), state name vs code (`Maine/ME`), missing number or street, extra `PO Box`, typos in city
  (`PITTSFIEDL`), zero-padding (`01466`), number suffix noise (`146D`, `2670-`), `DOOR NO`/`PLOT NO`/`KH NO` prefixes,
  landmark refs (`Near Gokulam Dairy`), empty address (~3%).

---

## 2. Research basis (what the literature/practice says and how we use it)

| Source | Takeaway | How we use it |
|---|---|---|
| Sparkly, PVLDB 2023 — top-k TF/IDF blocking beats 8 SOTA blockers ([paper](https://www.vldb.org/pvldb/vol16/p1507-paulsen.pdf)) | Simple top-k TF-IDF (per attribute, good tokenizer) is a very strong blocker | Main blocker = top-k TF-IDF cosine on names + addresses, within country |
| ING `sparse_dot_topn` ([repo](https://github.com/ing-bank/sparse_dot_topn), [blog](https://bergvca.github.io/2017/10/14/super-fast-string-matching.html)) | Char-n-gram TF-IDF + sparse top-n matmul matches millions of company names fast and memory-light | Implementation of the TF-IDF blocker (chunked, multithreaded) |
| Pre-trained embeddings for ER, PVLDB 2023 ([arXiv 2304.12329](https://arxiv.org/abs/2304.12329)) | Sentence-embedding models give the best dense blocking recall | Optional dense blocker for the hard residue (non-Latin names, heavy typos) |
| multilingual-e5-small, Apache-2.0, 118M params ([HF](https://huggingface.co/intfloat/multilingual-e5-small)) | Cross-lingual similarity incl. Indic scripts, license-compliant | Optional: embed only non-Latin / low-recall records (CPU budget limited) |
| Ditto, PVLDB 2020 ([arXiv 2004.00584](https://arxiv.org/abs/2004.00584)) | Fine-tuned transformer cross-encoders are SOTA matchers on small benchmarks | Too slow on CPU for ~50M pairs; use as *idea* (field-aware, data augmentation), not as main model |
| DL for Blocking design space, PVLDB 2021 ([paper](https://vldb.org/pvldb/vol14/p2459-thirumuruganathan.pdf)) | Hybrid lexical + semantic blocking maximises recall | Union of blockers, measure recall of each |
| Company name matching practice (cleanco, rapidfuzz — [D&B blog](https://medium.com/dnb-data-science-hub/company-name-matching-6a6330710334), [rapidfuzz](https://rapidfuzz.com/)) | Strip legal suffixes, normalise, then Jaro-Winkler/token-set/partial ratios | Feature set for the matcher |
| anyascii (ISC) / indic-transliteration (MIT) | Offline Unicode→Latin transliteration, no external lookup | Transliterate Indic names before blocking/features |

**Fair-play note:** Several teams have public GitHub repos for this exact challenge *during* the hackathon. We will
**not** look at or reuse them — code is reviewed, and plagiarism/shared code is a disqualification risk. Everything
below is built from the provided data + general open-source libraries.

### 2b. Competitive intel (public participant repos, read 25 Sep — ideas only, no code copied)

Rules forbid only *external data lookup*; reading public write-ups for ideas is not prohibited. We copy **no code**
(top packages are reviewed; code similarity with another team is a risk). Sources saved in `research/`.

| Team / repo | What they did | Reported numbers | What we take / improve |
|---|---|---|---|
| Aamod007 "DataResolvers" | 4 inverted-index blockers (name tokens, street# + locality prefix, rare address-token pairs, name-prefix+addr-prefix); 27 rapidfuzz features; XGBoost; threshold 0.94–0.95; 1-to-1 conflict resolution | Blocking recall **96.3%** @ 113 cands/S1; val F0.5 **0.965** (but on a small 184k pool → optimistic) | Benchmark to beat. Their recall ceiling is low and candidates/S1 high → our TF-IDF + address blocking should beat both. `addr_token_set` was by far their top feature. |
| Sanyam2005 (plan docs only) | Measured data facts + strategy: address-first, twin distractors, learned Indic dictionary, test-like validation, context model, expected-F0.5 decision | No scores yet | Most useful source. Claims below **verified by us** on train. |
| Sundramrai3691 | Scaffold: exact-key blocking + logistic regression | none | nothing new |
| Princeraj1105 | Small LightGBM pipeline | none | nothing new |
| others | Only problem README | — | — |

**Verified facts adopted from that intel (our own measurements):**
- **Name reuse:** 49% of S1 rows share a suffix-stripped sorted-token name key with another S1 → name alone cannot
  identify the entity; **address is the primary discriminator** (house number, street, city).
- **Indic names are word-by-word phonetic renderings** of the English name: token counts equal in 99.99% of pairs;
  a token dictionary learned from train pairs (≈1.5k entries) covers 99.97% of held-out tokens at 96.6% accuracy
  → **learned dictionary = primary transliteration**, `anyascii`/`indic-transliteration` only as fallback.
- (Claimed, to verify during build) distractors are adversarial "twins" (same name, different address); ~1% of twins
  sit on the same street with a nearby number; true matches also carry number noise (leading zeros, truncation, ±1,
  full replacement where S2 and S3 agree with each other but not with S1); ~18% of true pairs share no number.

**Plan upgrades from this (applied below):**
1. Address-centric blocking + **reverse-direction blocking** (each S2/S3 → its top S1s), recall target **≥ 99%**.
2. Extra normalisation: l33t (`0→o, 1→l, 5→s`), literal `null` in addresses, `dba` handling, random accents,
   domain decoding with word segmentation using the name vocabulary.
3. Features: **name-key frequency** (how generic the name is), rich house-number features (equal / zero-stripped /
   prefix / ±1 / absent vs different), twin flag, **S2↔S3 cluster agreement**, competition (candidate's best other S1).
4. **Test-like validation**: in the val fold, drop ~20% of S1 but keep their S2/S3 in the pool → more orphan
   distractors, like test (5.8 vs 4.7 S2/S3 per S1). Tune thresholds there.
5. **Per-S1 expected-F0.5 decision** on calibrated probabilities (choose k best candidates maximising E[F0.5];
   k = 0 handles singletons) — compare against the global threshold.
6. Do NOT feed `country` as a feature (France must reuse same features).
7. We have **no GPU** → skip fine-tuned cross-encoders/bi-encoders; our edge must come from better blocking,
   parsing, context features and decision rule (which is where most of the gain is anyway).

---

## 3. Architecture

```
 TSV ──► [A] Normalise ──► [B] Blocking (union of blockers, per country) ──► candidate_pairs.tsv
                                         │
                                         ▼
                            [C] Pair features (rapidfuzz, TF-IDF cos, numbers, tokens)
                                         │
                                         ▼
                            [D] LightGBM matcher  → P(match) per pair
                                         │
                                         ▼
                            [E] Context features / 2nd-stage (rank, gap, group consistency)
                                         │
                                         ▼
                            [F] Decision: 1-to-many assignment + F0.5-tuned thresholds ──► matching_results.tsv
```

### [A] Normalisation (`src/normalize.py`)
- Unicode NFKC, lowercase, strip accents (keep a copy with accents for French features).
- **Transliterate** non-Latin scripts with `anyascii` → then a phonetic "skeleton" (collapse doubled letters,
  map `aa/ee/oo`→`a/i/u`, `sh/s`, `v/w`, `ph/f`, drop vowels variant) so `lakshmi`≈`lksmi`.
- Remove junk prefixes/brackets/punctuation (`<< -- >> ## [ ] ( )`), `&`→`and`, domain → split (`raabmoderntreasury.com`
  → strip TLD, keep concatenated string for char-gram match).
- **Legal suffixes** (per country, extendable): US `inc, llc, pllc, corp, co, ltd, lp, llp, pc`; India
  `pvt, private, ltd, limited, llp, opc`; France `sas, sasu, sarl, sa, sci, snc, eurl, cie, scop, ets/établissements`.
  Produce `name_core` (without) + `legal_set` (normalised category).
- Generic words list learned from data (very frequent tokens like `services, holdings, group, solutions`) → down-weight.
- Address parsing (regex, no external lookups): house/plot numbers (strip zero-padding, suffix letters), ZIP (US 5-digit),
  PIN (India 6-digit), French postcode (5-digit) if present, state (map full name ↔ code: US 50 states, Indian
  states/UTs, French régions), city (token before state), street tokens with abbreviation expansion
  (`rd→road, st→street, ave→avenue, dr→drive, ln→lane, blvd→boulevard, ct→court, pl→place, r/r.→rue, bd→boulevard,
  av→avenue, chem→chemin, imp→impasse`), landmark flag (`near/opp/behind`).
- Store as parquet with categorical/int32 ids to save RAM.

### [B] Blocking / candidate generation (`src/blocking.py`)
Goal: **recall ≥ 97–98%** of true pairs with ≤ ~30–40 candidates per S1 (reduction ratio ≫ 99.99%).
All blockers run **within country** (0% cross-country matches) and in S1 chunks to bound memory.
1. **Name TF-IDF (char 3-grams of `name_core` + transliterated)** — top-k cosine (k≈15) via sparse_dot_topn.
2. **Address TF-IDF (word + char n-grams of normalised address)** — top-k (k≈15); rescues Indic-script names
   and heavily mangled names.
3. **Combined string TF-IDF** (name_core + city + number) — top-k (k≈10).
4. **Exact keys** (cheap, high precision): (sorted name tokens), (house number + street token + city),
   (first name token + city), (domain-concatenated name). Cap block size to avoid giant blocks.
5. Optional **dense blocker** (multilingual-e5-small) only for S1 whose best lexical candidate is weak.
- Union → dedupe → cap per S1 by a cheap pre-score (max of the cosine sims) → `candidate_pairs.tsv`.
- Measure on validation: **pair recall**, **entity-level recall ceiling (max achievable F0.5)**, avg candidates/S1.
- Note: the scorer/auditor looks at the *final* candidate set fed to the model — so the file must be exactly what the
  model scores.

### [C] Pair features (`src/features.py`) — ~40–60 features, all country-agnostic
- Name: rapidfuzz `ratio`, `partial_ratio`, `token_sort_ratio`, `token_set_ratio`, `WRatio`, Jaro-Winkler,
  normalised Levenshtein, on raw-clean / core / skeleton / sorted-token strings; TF-IDF cosine (char & word);
  token Jaccard (IDF-weighted); # shared rare tokens; first-token match; acronym match; length diff; legal-suffix
  agree/conflict; name contains other; domain-form flag; non-Latin flag.
- Address: TF-IDF cosine; token Jaccard; house number exact / partial / conflict / missing; ZIP/PIN/postcode equal /
  conflict / missing; street name similarity (JW); city similarity; state equal; PO box flag; landmark flag;
  empty address flag.
- Source & context: source (S2/S3), country (**as feature only if it doesn't hurt France — test with and without**),
  blocker hits (which blockers found the pair, count), block rank of pair.
- Use numpy-vectorised rapidfuzz (`process.cpdist` for paired scoring) + multiprocessing over chunks.

### [D] Matcher (`src/train.py`)
- **LightGBM** (MIT) binary classifier on candidate pairs from the training blocking output (natural hard negatives).
- Train on a subsample (e.g. 400–600k S1 entities → ~15–20M pairs, downsample easy negatives) to fit RAM.
- Validation: **group split by S1 entity**, 80/20; pool of S2/S3 = all train S2/S3 (realistic distractors).
- **France proxy:** train on US only → evaluate on India (and vice-versa) to measure generalisation to an unseen
  country; prefer features that transfer.
- Optional later: CatBoost/XGBoost blend; small cross-encoder only as re-ranker on uncertain pairs if CPU time allows.

### [E] Context / second stage (`src/context.py`) — often the biggest gain in ER
- Per S1: candidate's score rank, gap to best, # candidates above 0.5, max score of same source.
- Per S2/S3 record: its rank among all S1s that proposed it, score gap to its best S1 (competition feature —
  directly exploits the "≤1 S1 per S2/S3" rule).
- Group consistency: similarity of candidate to the *other* high-confidence matches of the same S1 (duplicates in
  a group resemble each other).
- Re-train LightGBM stage-2 with these features (out-of-fold stage-1 scores to avoid leakage).

### [F] Decision & output (`src/predict.py`)
- Enforce one-S1-per-S2/S3: keep each S2/S3 only for its argmax S1.
- Threshold `t` tuned to **maximise macro F0.5 on validation** (exact metric implementation); consider per-country
  and per-source thresholds; a separate, stricter one for France (no labels → start at US/India optimum + margin,
  check predicted-match-count distribution vs train: ~3.5/entity, ~5.6% empty).
- Singleton rule: if max P < t_empty → empty list.
- Write both TSVs; run `utils/validate_submission.py` every time.

### France strategy (no training labels)
1. Language-independent features (similarities, number agreement) do most of the work.
2. French-specific normalisation (abbrevs, legal forms, accents, `R.`/`Rue`, `St`/`Saint` ambiguity).
3. Check France prediction statistics (matches/entity, score distributions) vs US/India.
4. **Pseudo-labelling:** take very confident France pairs (e.g. P>0.97 & mutual best) + confident negatives,
   add to training, retrain → one self-training round. Only keep if US/India validation doesn't drop.

---

## 4. Metric implementation (must match organisers)
```
per S1: P = |pred ∩ true| / |pred|, R = |pred ∩ true| / |true|
  if true = ∅ : score = 1.0 if pred = ∅ else 0.0
  if pred = ∅ and true ≠ ∅ : score = 0.0
  else F0.5 = 1.25·P·R / (0.25·P + R)   (0 if P=R=0)
final = mean over all S1
```
(`src/metric.py`, unit-tested with the README example → 0.714.)

---

## 5. Timeline (IST)

| When | Milestone | Exit criterion |
|---|---|---|
| **25 Sep AM** | Env setup (`rapidfuzz lightgbm anyascii sparse_dot_topn polars`), data → parquet, normalisation v1, metric | metric test passes |
| **25 Sep PM** | Blocking v1 on train (US + India), recall report; heuristic baseline (threshold on name+addr sim) | recall ≥ 95%; **first leaderboard submission** |
| **25 Sep night** | Features v1 + LightGBM v1, threshold tuning, run on test | **Submission #2**, validation F0.5 logged |
| **26 Sep AM** | Blocking v2 (recall push, Indic transliteration, address blocker), features v2 | recall ≥ 97.5% |
| **26 Sep PM** | Stage-2 context features, 1-to-many assignment, per-country thresholds | Submission #3 |
| **26 Sep night** | France: normalisation + LOCO test + pseudo-labelling; error analysis of FP/FN | Submission #4 |
| **27 Sep AM** | Final improvements / blend, full clean re-run from scratch via README command | reproducible |
| **27 Sep 18:00** | **Freeze.** Fill Documentation_template.md, build zip, validate, upload | zip + final TSV submitted |
| 27 Sep 18:00–23:59 | Buffer only (no risky changes) | — |

---

## 5b. Compute split (decided 25 Sep): laptop + Colab Free
- **Laptop (16 cores, 15.7 GB):** everything CPU-bound — normalisation, TF-IDF/key blocking, rapidfuzz features,
  LightGBM, decision, output. Code lives here as `src/*.py` (= submission format).
- **Colab Free (T4 16 GB, ~12.7 GB RAM, 2 CPU, ~12 h sessions):** GPU-only jobs, run via a thin notebook that
  imports our `src/`:
  1. multilingual-e5-small/base embeddings (Apache-2.0/MIT) → dense top-k blocking for hard residue (FAISS-GPU).
  2. Optional GPU training of LightGBM/XGBoost on big feature sets.
- Data on Colab: zip in Google Drive → copy + unzip to `/content` each session; checkpoint every stage's outputs
  (parquet, `.npy` embeddings, models) back to Drive. Results come back to the laptop via Drive.

## 5c. GPU plan for 26 Sep (lab GPU)
- Fine-tune a small MIT/Apache sentence encoder (Snowflake arctic-embed-xs 22M, or multilingual-e5-small 118M) with
  contrastive loss on train pairs (name + address text), hard negatives = same-name twins → dense blocking leg
  (both directions, per country) added to the TF-IDF union. SABER reports India recall@20 0.835→0.992 from this.
- If time: cross-encoder re-ranker score as an extra feature on the ~40 candidates/S1.

## 6. Engineering constraints & tactics (16 GB RAM, CPU only)
- Read TSV with `quoting=3`(none), `dtype=str`, `keep_default_na=False` (empty ≠ NaN); convert to parquet once.
- Process **per country** and in **S1 chunks** (~100–200k) for blocking/features; stream pair features to disk (parquet
  shards), never hold all pairs in RAM.
- Int32 row indices instead of string ids inside pipelines; map back to ids only at write time.
- float32 features; LightGBM with `max_bin` 63–127, `num_threads=16`.
- Time budget sanity check: ~1.73M S1 × ~35 candidates ≈ 60M test pairs → feature extraction must hit ≥ 50k pairs/s
  (vectorised rapidfuzz + 16 processes).

## 7. Repo layout (matches required submission)
```
D:\mlchallenge\
  PLAN.md, SESSION_LOG.md, eda/
  work/                         # parquet caches, pair shards, models (not shipped)
  submission/
    output/matching_results.tsv, candidate_pairs.tsv
    code/business_entity_resolution/
      src/ normalize.py blocking.py features.py train.py context.py predict.py metric.py run_all.py
      README.md  requirements.txt (pinned)
    Documentation_template.md (filled)
```

## 8. Risks & mitigations
| Risk | Mitigation |
|---|---|
| OOM on 10M-record TF-IDF | per-country, chunked top-n, float32, drop rare/very common n-grams |
| Feature extraction too slow | cap candidates, cheap pre-filter, multiprocessing, only expensive features on survivors |
| France under-performs | agnostic features, French rules, pseudo-labels, stricter threshold |
| Over-fitting public LB (subset of test) | trust local validation; LB only as sanity check |
| Last-minute breakage | freeze at 18:00, keep last good submission files + zip ready |
| Rule violations | no external lookups, MIT/Apache models only, document every library |

## 9. Experiment tracker
| # | Date | Change | Blocking recall | Val F0.5 | LB F0.5 | Notes |
|---|---|---|---|---|---|---|
| — | — | — | — | — | — | — |
